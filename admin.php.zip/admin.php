<?php
// ==========================================
// PASSWORD-PROTECTED ADMIN PANEL (admin.php)
// Event-Wise Guest Access + Session-Free Auth
// ==========================================

// >>> CHANGE THIS PASSWORD BEFORE UPLOADING <<<
$ADMIN_PASSWORD = 'admin1234';

$configFile = __DIR__ . '/config.json';
$guestsFile = __DIR__ . '/guests.json';
$rsvpsFile  = __DIR__ . '/rsvps.json';

$cookieName  = 'wedding_admin_auth_v2';
$expectedSig = hash_hmac('sha256', 'wedding_studio_unlocked', $ADMIN_PASSWORD);

// Logout Handler
if (isset($_GET['logout'])) {
    setcookie($cookieName, '', time() - 3600, '/');
    header('Location: ' . basename(__FILE__));
    exit;
}

// Login Handler
$loginError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_password'])) {
    if (hash_equals($ADMIN_PASSWORD, (string)$_POST['login_password'])) {
        setcookie($cookieName, $expectedSig, time() + (86400 * 7), '/');
        header('Location: ' . basename(__FILE__));
        exit;
    } else {
        $loginError = 'Incorrect password. Please try again.';
    }
}

$isAuthenticated = isset($_COOKIE[$cookieName]) && hash_equals($expectedSig, (string)$_COOKIE[$cookieName]);

if (!$isAuthenticated):
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login — Wedding Invitation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600&family=Plus+Jakarta+Sans:wght@400;500;600&display=swap" rel="stylesheet">
</head>
<body class="min-h-screen bg-[#181C14] text-stone-100 flex items-center justify-center p-4 font-['Plus_Jakarta_Sans']">
    <div class="w-full max-w-sm bg-[#22271D] border border-amber-500/25 rounded-2xl p-8 shadow-2xl">
        <div class="text-center mb-6">
            <p class="text-[11px] uppercase tracking-[0.25em] text-amber-400 mb-1">Private Access</p>
            <h1 class="font-['Cinzel'] text-2xl font-semibold text-white">Invitation Manager</h1>
        </div>
        <?php if ($loginError): ?>
            <div class="mb-4 p-3 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs text-center">
                <?= htmlspecialchars($loginError) ?>
            </div>
        <?php endif; ?>
        <form method="POST" class="space-y-4">
            <div>
                <label class="block text-xs uppercase tracking-wider text-stone-400 mb-1.5">Admin Password</label>
                <input type="password" name="login_password" required autofocus placeholder="Enter password" class="w-full px-4 py-3 rounded-xl bg-black/30 border border-white/15 text-white focus:outline-none focus:border-amber-400 text-sm">
            </div>
            <button type="submit" class="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-semibold text-sm transition cursor-pointer">
                Unlock Dashboard
            </button>
        </form>
    </div>
</body>
</html>
<?php
exit;
endif;

$defaultConfig = [
    'bismillah_arabic' => 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ',
    'bismillah_text'   => 'In the name of Allah, the Most Gracious, the Most Merciful',
    'monogram'         => 'A & R',
    'bride_name'       => 'Ayesha Siddiqua',
    'groom_name'       => 'Rahim Uddin',
    'tagline'          => 'Two souls, one beautiful journey — begun with blessings',
    'parents_text'     => 'Together with their beloved parents, Mr. & Mrs. Abdul Karim and Mr. & Mrs. Nurul Islam',
    'invite_message'   => 'We joyfully request the honor of your presence and prayers as we unite in marriage and celebrate the beginning of our new life together.',
    'wedding_date'     => '2027-02-12T17:00:00',
    'date_display'     => 'FRIDAY, 12 FEBRUARY 2027 • 5:00 PM',
    'music_url'        => '',
    'theme'            => 'olive_gold',
    'font_preset'      => 'royal_editorial',
    'custom_colors'    => ['envelope' => '#F2E6CE', 'bg' => '#1D1812', 'surface' => '#FCF8F0', 'accent' => '#B88928', 'text' => '#2A2115'],
    'events'           => [],
    'public_events'    => null,
    'contacts'         => []
];

if (!file_exists($configFile)) {
    @file_put_contents($configFile, json_encode($defaultConfig, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
}
$loadedConfig = file_exists($configFile) ? json_decode(@file_get_contents($configFile), true) : null;
$config = is_array($loadedConfig) ? array_merge($defaultConfig, $loadedConfig) : $defaultConfig;

// Ensure every event has a stable unique ID
if (!empty($config['events']) && is_array($config['events'])) {
    foreach ($config['events'] as $i => &$ev) {
        if (empty($ev['id'])) {
            $ev['id'] = 'ev_' . substr(md5(($ev['title'] ?? 'event') . '_' . $i), 0, 8);
        }
    }
    unset($ev);
}

$guests = file_exists($guestsFile) ? (json_decode(@file_get_contents($guestsFile), true) ?: []) : [];
$rsvps  = file_exists($rsvpsFile) ? (json_decode(@file_get_contents($rsvpsFile), true) ?: []) : [];

$toastMessage = '';
$errorAlert   = '';
$activeTab    = $_GET['tab'] ?? 'details';

if (!is_writable(__DIR__)) {
    $errorAlert = 'Warning: Folder is not writable. Please set folder permission to 0755 in cPanel.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['form_action'] ?? '';

    if ($action === 'save_details') {
        $config['bismillah_arabic'] = trim($_POST['bismillah_arabic'] ?? '');
        $config['bismillah_text']   = trim($_POST['bismillah_text'] ?? '');
        $config['monogram']         = trim($_POST['monogram'] ?? 'A & R');
        $config['bride_name']       = trim($_POST['bride_name'] ?? '');
        $config['groom_name']       = trim($_POST['groom_name'] ?? '');
        $config['tagline']          = trim($_POST['tagline'] ?? '');
        $config['parents_text']     = trim($_POST['parents_text'] ?? '');
        $config['invite_message']   = trim($_POST['invite_message'] ?? '');
        $config['wedding_date']     = trim($_POST['wedding_date'] ?? '');
        $config['date_display']     = trim($_POST['date_display'] ?? '');
        $config['music_url']        = trim($_POST['music_url'] ?? '');

        $events = [];
        if (!empty($_POST['event_title']) && is_array($_POST['event_title'])) {
            foreach ($_POST['event_title'] as $idx => $title) {
                if (trim($title) === '') continue;
                $evId = trim($_POST['event_id'][$idx] ?? '');
                if ($evId === '') {
                    $evId = 'ev_' . substr(md5(uniqid((string)mt_rand(), true)), 0, 8);
                }
                $events[] = [
                    'id'         => $evId,
                    'title'      => trim($title),
                    'date'       => trim($_POST['event_date'][$idx] ?? ''),
                    'time'       => trim($_POST['event_time'][$idx] ?? ''),
                    'venue'      => trim($_POST['event_venue'][$idx] ?? ''),
                    'dress_code' => trim($_POST['event_dress'][$idx] ?? ''),
                    'map_url'    => trim($_POST['event_map'][$idx] ?? '')
                ];
            }
        }
        $config['events'] = $events;

        $contacts = [];
        if (!empty($_POST['contact_name']) && is_array($_POST['contact_name'])) {
            foreach ($_POST['contact_name'] as $idx => $cname) {
                if (trim($cname) === '' || trim($_POST['contact_phone'][$idx] ?? '') === '') continue;
                $contacts[] = [
                    'name'  => trim($cname),
                    'phone' => trim($_POST['contact_phone'][$idx])
                ];
            }
        }
        $config['contacts'] = $contacts;

        if (@file_put_contents($configFile, json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX) !== false) {
            $toastMessage = 'Wedding details saved successfully!';
        } else {
            $errorAlert = 'Could not save config.json. Check folder permissions (0755).';
        }
        $activeTab = 'details';
    }

    if ($action === 'save_design') {
        $config['theme']       = $_POST['theme'] ?? 'olive_gold';
        $config['font_preset'] = $_POST['font_preset'] ?? 'royal_editorial';
        $config['custom_colors'] = [
            'envelope' => $_POST['custom_envelope'] ?? '#F2E6CE',
            'bg'       => $_POST['custom_bg'] ?? '#1D1812',
            'surface'  => $_POST['custom_surface'] ?? '#FCF8F0',
            'accent'   => $_POST['custom_accent'] ?? '#B88928',
            'text'     => $_POST['custom_text'] ?? '#2A2115'
        ];
        @file_put_contents($configFile, json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
        $toastMessage = 'Theme and typography updated!';
        $activeTab = 'design';
    }

    if ($action === 'add_guests') {
        $rawLines = explode("\n", $_POST['guest_names'] ?? '');
        $selectedEvents = isset($_POST['allowed_events']) && is_array($_POST['allowed_events'])
            ? array_values(array_map('strval', $_POST['allowed_events']))
            : [];
        $addedCount = 0;

        foreach ($rawLines as $line) {
            $name = trim($line);
            if ($name === '') continue;

            $slug = strtolower(preg_replace('/[^a-zA-Z0-9]+/', '-', $name));
            $slug = trim($slug, '-');
            if ($slug === '') $slug = 'guest';
            $slug = substr($slug, 0, 18);

            $randomCode = substr(md5(uniqid((string)mt_rand(), true)), 0, 4);
            $token = $slug . '-' . $randomCode;

            array_unshift($guests, [
                'token'          => $token,
                'name'           => $name,
                'allowed_events' => $selectedEvents,
                'views'          => 0,
                'last_viewed'    => null
            ]);
            $addedCount++;
        }

        if ($addedCount > 0) {
            @file_put_contents($guestsFile, json_encode($guests, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
            $toastMessage = "{$addedCount} secure guest link(s) generated with custom event access!";
        }
        $activeTab = 'guests';
    }

    if ($action === 'update_guest_events') {
        $targetToken = $_POST['token'] ?? '';
        $updatedEvents = isset($_POST['guest_events']) && is_array($_POST['guest_events'])
            ? array_values(array_map('strval', $_POST['guest_events']))
            : [];

        foreach ($guests as &$g) {
            if (($g['token'] ?? '') === $targetToken) {
                $g['allowed_events'] = $updatedEvents;
                break;
            }
        }
        unset($g);

        @file_put_contents($guestsFile, json_encode($guests, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
        $toastMessage = 'Guest event permissions updated!';
        $activeTab = 'guests';
    }

    if ($action === 'save_public_events') {
        $pubEvents = isset($_POST['public_events']) && is_array($_POST['public_events'])
            ? array_values(array_map('strval', $_POST['public_events']))
            : [];
        $config['public_events'] = $pubEvents;
        @file_put_contents($configFile, json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
        $toastMessage = 'Public link event visibility saved!';
        $activeTab = 'guests';
    }

    if ($action === 'delete_guest') {
        $delToken = $_POST['token'] ?? '';
        $newGuests = [];
        foreach ($guests as $g) {
            if (($g['token'] ?? '') !== $delToken) {
                $newGuests[] = $g;
            }
        }
        $guests = $newGuests;
        @file_put_contents($guestsFile, json_encode($guests, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
        $toastMessage = 'Guest link revoked and removed.';
        $activeTab = 'guests';
    }

    if ($action === 'delete_rsvp') {
        $delId = $_POST['rsvp_id'] ?? '';
        $newRsvps = [];
        foreach ($rsvps as $r) {
            if (($r['id'] ?? '') !== $delId) {
                $newRsvps[] = $r;
            }
        }
        $rsvps = $newRsvps;
        @file_put_contents($rsvpsFile, json_encode($rsvps, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
        $toastMessage = 'RSVP entry removed.';
        $activeTab = 'rsvps';
    }
}

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$dirPath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$baseUrl = $scheme . '://' . $_SERVER['HTTP_HOST'] . $dirPath . '/';

// Map Event ID => Title for quick badge lookup
$eventTitleMap = [];
foreach (($config['events'] ?? []) as $ev) {
    $eventTitleMap[$ev['id']] = $ev['title'];
}

$themeCatalog = [
    'olive_gold'          => ['label' => 'Royal Ivory & Gold (Default)', 'colors' => ['#F3E7CE', '#FCF8F0', '#B88928']],
    'emerald_gold'        => ['label' => 'Royal Emerald & Gold', 'colors' => ['#073B2C', '#083E2F', '#D4AF37']],
    'maroon_cream'        => ['label' => 'Classic Maroon & Cream', 'colors' => ['#59111B', '#FCF6EC', '#B8862D']],
    'dusty_rose'          => ['label' => 'Dusty Rose & Champagne', 'colors' => ['#965163', '#FEF7F7', '#B87684']],
    'midnight_navy'       => ['label' => 'Midnight Navy & Silver', 'colors' => ['#0F223D', '#0D1E36', '#D6C08D']],
    'ivory_terracotta'    => ['label' => 'Ivory Pearl & Terracotta', 'colors' => ['#A85234', '#FCF8F2', '#B55B3C']],
    'sage_brass'          => ['label' => 'Sage Olive & Antique Brass', 'colors' => ['#374A3A', '#F7F8F3', '#B68F40']],
    'obsidian_rosegold'   => ['label' => 'Obsidian Charcoal & Rose Gold', 'colors' => ['#1A181B', '#171518', '#E2A796']],
    'aubergine_champagne' => ['label' => 'Royal Aubergine & Champagne', 'colors' => ['#3B143A', '#30102F', '#E5C382']],
    'peacock_saffron'     => ['label' => 'Peacock Teal & Saffron Gold', 'colors' => ['#094E5E', '#F8FAFA', '#D18F19']],
    'custom'              => ['label' => 'Custom Color Palette', 'colors' => ['#444444', '#FFFFFF', '#D4AF37']]
];

$attendingGuests = 0;
$declinedCount   = 0;
foreach ($rsvps as $r) {
    if (($r['status'] ?? '') === 'Joyfully Attending') {
        $attendingGuests += (int)($r['guests'] ?? 1);
    } else {
        $declinedCount++;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wedding Card Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="min-h-screen bg-[#141712] text-stone-100 font-['Plus_Jakarta_Sans']">

    <header class="bg-[#1C2019] border-b border-white/10 sticky top-0 z-30">
        <div class="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-4">
            <div>
                <h1 class="font-['Cinzel'] text-xl sm:text-2xl font-semibold text-amber-400">Wedding Card Studio</h1>
                <p class="text-xs text-stone-400">Manage content, themes, event-wise guest links &amp; RSVPs</p>
            </div>
            <div class="flex items-center gap-3">
                <a href="<?= htmlspecialchars($baseUrl) ?>" target="_blank" class="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold transition">
                    Preview Public Card ↗
                </a>
                <a href="?logout=1" class="px-4 py-2 rounded-xl bg-red-500/15 hover:bg-red-500/25 text-red-300 border border-red-500/25 text-xs font-semibold transition">
                    Logout
                </a>
            </div>
        </div>
    </header>

    <main class="max-w-6xl mx-auto px-4 sm:px-6 py-8">

        <?php if ($errorAlert): ?>
            <div class="mb-6 p-4 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-sm">
                <?= htmlspecialchars($errorAlert) ?>
            </div>
        <?php endif; ?>

        <?php if ($toastMessage): ?>
            <div class="mb-6 p-4 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-sm flex items-center justify-between">
                <span><?= htmlspecialchars($toastMessage) ?></span>
                <button onclick="this.parentElement.remove()" class="text-emerald-300/70 hover:text-white">✕</button>
            </div>
        <?php endif; ?>

        <div class="flex flex-wrap gap-2 mb-8 border-b border-white/10 pb-4">
            <a href="?tab=details" class="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition <?= $activeTab === 'details' ? 'bg-amber-500 text-stone-950' : 'bg-white/5 text-stone-300 hover:bg-white/10' ?>">
                1. Wedding &amp; Events
            </a>
            <a href="?tab=design" class="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition <?= $activeTab === 'design' ? 'bg-amber-500 text-stone-950' : 'bg-white/5 text-stone-300 hover:bg-white/10' ?>">
                2. Theme &amp; Typography
            </a>
            <a href="?tab=guests" class="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition <?= $activeTab === 'guests' ? 'bg-amber-500 text-stone-950' : 'bg-white/5 text-stone-300 hover:bg-white/10' ?>">
                3. Guest Links &amp; Event Access (<?= count($guests) ?>)
            </a>
            <a href="?tab=rsvps" class="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition <?= $activeTab === 'rsvps' ? 'bg-amber-500 text-stone-950' : 'bg-white/5 text-stone-300 hover:bg-white/10' ?>">
                4. RSVPs &amp; Wishes (<?= count($rsvps) ?>)
            </a>
        </div>

        <?php if ($activeTab === 'details'): ?>
            <form method="POST" class="space-y-8">
                <input type="hidden" name="form_action" value="save_details">

                <div class="bg-[#1C2019] border border-white/10 rounded-2xl p-6 space-y-5">
                    <h2 class="text-lg font-semibold text-amber-400">Couple &amp; Envelope Details</h2>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">Envelope Gold Monogram</label>
                            <input type="text" name="monogram" value="<?= htmlspecialchars($config['monogram'] ?? 'A & R') ?>" placeholder="e.g. A & R" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                        </div>
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">Bride's Name</label>
                            <input type="text" name="bride_name" required value="<?= htmlspecialchars($config['bride_name'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                        </div>
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">Groom's Name</label>
                            <input type="text" name="groom_name" required value="<?= htmlspecialchars($config['groom_name'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">Arabic Header (Optional)</label>
                            <input type="text" name="bismillah_arabic" value="<?= htmlspecialchars($config['bismillah_arabic'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                        </div>
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">Auspicious Sub-header</label>
                            <input type="text" name="bismillah_text" value="<?= htmlspecialchars($config['bismillah_text'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">Tagline</label>
                            <input type="text" name="tagline" value="<?= htmlspecialchars($config['tagline'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                        </div>
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">Default Display Date Text</label>
                            <input type="text" name="date_display" value="<?= htmlspecialchars($config['date_display'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                        </div>
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">Countdown Target (YYYY-MM-DDTHH:MM:SS)</label>
                            <input type="text" name="wedding_date" value="<?= htmlspecialchars($config['wedding_date'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs text-stone-400 mb-1">Custom Background Music MP3 URL (Leave empty for built-in Royal Wedding Chime)</label>
                        <input type="url" name="music_url" value="<?= htmlspecialchars($config['music_url'] ?? '') ?>" placeholder="https://example.com/wedding-melody.mp3 (Optional)" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                    </div>

                    <div>
                        <label class="block text-xs text-stone-400 mb-1">Parents' Names Line</label>
                        <input type="text" name="parents_text" value="<?= htmlspecialchars($config['parents_text'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                    </div>

                    <div>
                        <label class="block text-xs text-stone-400 mb-1">Main Invitation Message</label>
                        <textarea name="invite_message" rows="3" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm"><?= htmlspecialchars($config['invite_message'] ?? '') ?></textarea>
                    </div>
                </div>

                <div class="bg-[#1C2019] border border-white/10 rounded-2xl p-6 space-y-5">
                    <div class="flex items-center justify-between">
                        <h2 class="text-lg font-semibold text-amber-400">Event Schedule</h2>
                        <button type="button" onclick="addEventRow()" class="px-3.5 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-semibold hover:bg-amber-500/30">
                            + Add Event
                        </button>
                    </div>

                    <div id="events-container" class="space-y-4">
                        <?php foreach (($config['events'] ?? []) as $ev): ?>
                            <div class="p-4 rounded-xl bg-black/25 border border-white/10 space-y-3 relative event-row">
                                <input type="hidden" name="event_id[]" value="<?= htmlspecialchars($ev['id']) ?>">
                                <button type="button" onclick="this.parentElement.remove()" class="absolute top-3 right-3 text-xs text-red-400 hover:underline">Remove</button>
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                                    <input type="text" name="event_title[]" value="<?= htmlspecialchars($ev['title']) ?>" placeholder="Event Title" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                                    <input type="text" name="event_date[]" value="<?= htmlspecialchars($ev['date']) ?>" placeholder="Date" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                                    <input type="text" name="event_time[]" value="<?= htmlspecialchars($ev['time']) ?>" placeholder="Time" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                                </div>
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                                    <input type="text" name="event_venue[]" value="<?= htmlspecialchars($ev['venue']) ?>" placeholder="Venue Address" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                                    <input type="text" name="event_dress[]" value="<?= htmlspecialchars($ev['dress_code'] ?? '') ?>" placeholder="Dress Code" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                                    <input type="url" name="event_map[]" value="<?= htmlspecialchars($ev['map_url'] ?? '') ?>" placeholder="Google Maps URL" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="bg-[#1C2019] border border-white/10 rounded-2xl p-6 space-y-4">
                    <div class="flex items-center justify-between">
                        <h2 class="text-lg font-semibold text-amber-400">Host Contacts (Call &amp; WhatsApp)</h2>
                        <button type="button" onclick="addContactRow()" class="px-3.5 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-semibold hover:bg-amber-500/30">
                            + Add Contact
                        </button>
                    </div>
                    <div id="contacts-container" class="space-y-3">
                        <?php foreach (($config['contacts'] ?? []) as $ct): ?>
                            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 items-center">
                                <input type="text" name="contact_name[]" value="<?= htmlspecialchars($ct['name']) ?>" placeholder="Name / Relation" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                                <input type="text" name="contact_phone[]" value="<?= htmlspecialchars($ct['phone']) ?>" placeholder="+8801XXXXXXXXX" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                                <button type="button" onclick="this.parentElement.remove()" class="text-xs text-red-400 hover:underline text-left sm:text-center">Remove</button>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <button type="submit" class="px-8 py-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-sm shadow-lg cursor-pointer">
                    Save All Wedding Details
                </button>
            </form>

        <?php elseif ($activeTab === 'design'): ?>
            <form method="POST" class="space-y-8">
                <input type="hidden" name="form_action" value="save_design">

                <div class="bg-[#1C2019] border border-white/10 rounded-2xl p-6 space-y-5">
                    <h2 class="text-lg font-semibold text-amber-400">Select Luxury Color Theme</h2>
                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        <?php foreach ($themeCatalog as $key => $info): ?>
                            <label class="cursor-pointer block">
                                <input type="radio" name="theme" value="<?= $key ?>" class="peer sr-only" <?= ($config['theme'] ?? 'olive_gold') === $key ? 'checked' : '' ?>>
                                <div class="p-4 rounded-xl border border-white/15 bg-black/25 peer-checked:border-amber-400 peer-checked:bg-amber-500/10 transition">
                                    <div class="flex items-center gap-2 mb-2.5">
                                        <?php foreach ($info['colors'] as $hex): ?>
                                            <span class="w-6 h-6 rounded-full border border-white/25" style="background-color: <?= $hex ?>;"></span>
                                        <?php endforeach; ?>
                                    </div>
                                    <p class="text-sm font-medium text-stone-200"><?= htmlspecialchars($info['label']) ?></p>
                                </div>
                            </label>
                        <?php endforeach; ?>
                    </div>

                    <div class="pt-4 border-t border-white/10">
                        <p class="text-xs uppercase tracking-wider text-stone-400 mb-3">Custom Color Palette (Active when "Custom Color Palette" is selected)</p>
                        <?php $cc = $config['custom_colors'] ?? ['envelope' => '#F2E6CE', 'bg' => '#1D1812', 'surface' => '#FCF8F0', 'accent' => '#B88928', 'text' => '#2A2115']; ?>
                        <div class="grid grid-cols-2 sm:grid-cols-5 gap-4">
                            <div>
                                <label class="block text-xs text-stone-400 mb-1">Envelope Color</label>
                                <input type="color" name="custom_envelope" value="<?= htmlspecialchars($cc['envelope']) ?>" class="w-full h-10 rounded cursor-pointer bg-transparent">
                            </div>
                            <div>
                                <label class="block text-xs text-stone-400 mb-1">Outer Backdrop</label>
                                <input type="color" name="custom_bg" value="<?= htmlspecialchars($cc['bg']) ?>" class="w-full h-10 rounded cursor-pointer bg-transparent">
                            </div>
                            <div>
                                <label class="block text-xs text-stone-400 mb-1">Card Surface</label>
                                <input type="color" name="custom_surface" value="<?= htmlspecialchars($cc['surface']) ?>" class="w-full h-10 rounded cursor-pointer bg-transparent">
                            </div>
                            <div>
                                <label class="block text-xs text-stone-400 mb-1">Gold / Accent</label>
                                <input type="color" name="custom_accent" value="<?= htmlspecialchars($cc['accent']) ?>" class="w-full h-10 rounded cursor-pointer bg-transparent">
                            </div>
                            <div>
                                <label class="block text-xs text-stone-400 mb-1">Card Text</label>
                                <input type="color" name="custom_text" value="<?= htmlspecialchars($cc['text']) ?>" class="w-full h-10 rounded cursor-pointer bg-transparent">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bg-[#1C2019] border border-white/10 rounded-2xl p-6 space-y-4">
                    <h2 class="text-lg font-semibold text-amber-400">Typography Style</h2>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <label class="cursor-pointer block">
                            <input type="radio" name="font_preset" value="royal_editorial" class="peer sr-only" <?= ($config['font_preset'] ?? 'royal_editorial') === 'royal_editorial' ? 'checked' : '' ?>>
                            <div class="p-4 rounded-xl border border-white/15 bg-black/25 peer-checked:border-amber-400 peer-checked:bg-amber-500/10">
                                <p class="font-['Cinzel'] text-lg text-white mb-1">Royal Editorial Serif</p>
                                <p class="text-xs text-stone-400">Cinzel + Cormorant Garamond (Recommended)</p>
                            </div>
                        </label>
                        <label class="cursor-pointer block">
                            <input type="radio" name="font_preset" value="classic_aristocrat" class="peer sr-only" <?= ($config['font_preset'] ?? '') === 'classic_aristocrat' ? 'checked' : '' ?>>
                            <div class="p-4 rounded-xl border border-white/15 bg-black/25 peer-checked:border-amber-400 peer-checked:bg-amber-500/10">
                                <p class="font-serif text-lg text-white mb-1">Classic Aristocrat</p>
                                <p class="text-xs text-stone-400">Playfair Display + Lora</p>
                            </div>
                        </label>
                        <label class="cursor-pointer block">
                            <input type="radio" name="font_preset" value="modern_luxury" class="peer sr-only" <?= ($config['font_preset'] ?? '') === 'modern_luxury' ? 'checked' : '' ?>>
                            <div class="p-4 rounded-xl border border-white/15 bg-black/25 peer-checked:border-amber-400 peer-checked:bg-amber-500/10">
                                <p class="tracking-widest uppercase text-base font-semibold text-white mb-1">Modern Minimalist</p>
                                <p class="text-xs text-stone-400">Montserrat + Cormorant Garamond</p>
                            </div>
                        </label>
                    </div>
                </div>

                <button type="submit" class="px-8 py-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-sm shadow-lg cursor-pointer">
                    Apply Theme &amp; Typography
                </button>
            </form>

        <?php elseif ($activeTab === 'guests'): ?>
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Left Column: Generate Event-Specific Guest Links -->
                <div class="space-y-6">
                    <div class="bg-[#1C2019] border border-white/10 rounded-2xl p-6">
                        <h2 class="text-lg font-semibold text-amber-400 mb-1.5">Generate Guest Links</h2>
                        <p class="text-xs text-stone-400 mb-4 leading-relaxed">
                            Select which program(s) these guests are invited to. Unselected events will remain hidden on their card.
                        </p>
                        <form method="POST" class="space-y-4">
                            <input type="hidden" name="form_action" value="add_guests">

                            <!-- Program Selection Checkboxes -->
                            <div class="p-3.5 rounded-xl bg-black/30 border border-amber-500/25 space-y-2.5">
                                <div class="flex items-center justify-between">
                                    <span class="text-[11px] uppercase tracking-wider text-amber-300 font-semibold">Invited Programs:</span>
                                    <button type="button" onclick="toggleAllCreateEvents(true)" class="text-[11px] text-stone-400 hover:text-white underline">Select All</button>
                                </div>
                                <?php if (empty($config['events'])): ?>
                                    <p class="text-xs text-red-300">No events found. Add events in Tab 1 first.</p>
                                <?php else: ?>
                                    <?php foreach ($config['events'] as $ev): ?>
                                        <label class="flex items-center gap-2.5 text-xs text-stone-200 cursor-pointer hover:text-amber-300 transition">
                                            <input type="checkbox" name="allowed_events[]" value="<?= htmlspecialchars($ev['id']) ?>" checked class="create-event-cb w-4 h-4 rounded accent-amber-500 cursor-pointer">
                                            <span><?= htmlspecialchars($ev['title']) ?></span>
                                        </label>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>

                            <div>
                                <label class="block text-xs text-stone-400 mb-1.5">Guest Names (One per line)</label>
                                <textarea name="guest_names" rows="6" required placeholder="Mitu Apa & Family&#10;Dr. Tanvir Ahmed&#10;Engr. Mahmudul Hasan & Spouse" class="w-full px-3.5 py-3 rounded-xl bg-black/30 border border-white/15 text-sm leading-relaxed focus:outline-none focus:border-amber-400"></textarea>
                            </div>

                            <button type="submit" class="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-sm cursor-pointer">
                                + Generate Custom Links
                            </button>
                        </form>
                    </div>

                    <!-- Public Link Default Visibility -->
                    <div class="bg-[#1C2019] border border-white/10 rounded-2xl p-6">
                        <h3 class="text-sm font-semibold text-amber-400 mb-1">Public Link Default Programs</h3>
                        <p class="text-xs text-stone-400 mb-3">
                            Programs shown if someone opens the generic link without a personal guest token:
                        </p>
                        <form method="POST" class="space-y-3">
                            <input type="hidden" name="form_action" value="save_public_events">
                            <?php
                                $pubAllowed = $config['public_events'];
                                foreach (($config['events'] ?? []) as $ev):
                                    $isChecked = ($pubAllowed === null) || in_array($ev['id'], $pubAllowed, true);
                            ?>
                                <label class="flex items-center gap-2.5 text-xs text-stone-200 cursor-pointer">
                                    <input type="checkbox" name="public_events[]" value="<?= htmlspecialchars($ev['id']) ?>" <?= $isChecked ? 'checked' : '' ?> class="w-4 h-4 rounded accent-amber-500">
                                    <span><?= htmlspecialchars($ev['title']) ?></span>
                                </label>
                            <?php endforeach; ?>
                            <button type="submit" class="w-full py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold transition cursor-pointer">
                                Save Public Default
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Right Column: Registered Guests & Inline Event Editor -->
                <div class="lg:col-span-2 bg-[#1C2019] border border-white/10 rounded-2xl p-6">
                    <div class="flex items-center justify-between mb-4">
                        <h2 class="text-lg font-semibold text-amber-400">Registered Guests (<?= count($guests) ?>)</h2>
                        <span class="text-xs text-stone-400">Custom Event-Filtered Links</span>
                    </div>

                    <?php if (empty($guests)): ?>
                        <p class="text-sm text-stone-400 py-8 text-center">No guests added yet. Add names on the left to generate links.</p>
                    <?php else: ?>
                        <div class="space-y-3.5 max-h-[760px] overflow-y-auto pr-1">
                            <?php foreach ($guests as $idx => $g): ?>
                                <?php
                                    $guestLink = $baseUrl . '?to=' . urlencode($g['token']);
                                    $waText = rawurlencode("Assalamu Alaikum {$g['name']}, you are cordially invited to the wedding of {$config['bride_name']} & {$config['groom_name']}. Tap to open your personal invitation card: {$guestLink}");
                                    $gAllowed = $g['allowed_events'] ?? null; // null means all events (legacy compatibility)
                                ?>
                                <div class="p-4 rounded-xl bg-black/25 border border-white/10 space-y-3">
                                    <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                                        <div>
                                            <div class="flex flex-wrap items-center gap-2">
                                                <p class="font-semibold text-white text-sm"><?= htmlspecialchars($g['name']) ?></p>
                                                <?php if (($g['views'] ?? 0) > 0): ?>
                                                    <span class="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-semibold">
                                                        Opened <?= (int)$g['views'] ?>x
                                                    </span>
                                                <?php else: ?>
                                                    <span class="px-2 py-0.5 rounded-full bg-white/10 text-stone-400 text-[10px]">
                                                        Not opened yet
                                                    </span>
                                                <?php endif; ?>
                                            </div>

                                            <!-- Invited Event Badges -->
                                            <div class="flex flex-wrap gap-1.5 mt-2">
                                                <?php if ($gAllowed === null): ?>
                                                    <span class="px-2 py-0.5 rounded bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[10px]">
                                                        All Programs
                                                    </span>
                                                <?php elseif (empty($gAllowed)): ?>
                                                    <span class="px-2 py-0.5 rounded bg-red-500/15 border border-red-500/30 text-red-300 text-[10px]">
                                                        No Programs Selected
                                                    </span>
                                                <?php else: ?>
                                                    <?php foreach ($gAllowed as $evId): ?>
                                                        <?php if (isset($eventTitleMap[$evId])): ?>
                                                            <span class="px-2 py-0.5 rounded bg-amber-500/15 border border-amber-500/30 text-amber-200 text-[10px]">
                                                                ✓ <?= htmlspecialchars($eventTitleMap[$evId]) ?>
                                                            </span>
                                                        <?php endif; ?>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                            </div>

                                            <p class="text-xs text-amber-300/75 font-mono mt-2 break-all"><?= htmlspecialchars($guestLink) ?></p>
                                            <?php if (!empty($g['last_viewed'])): ?>
                                                <p class="text-[11px] text-stone-400 mt-0.5">Last opened: <?= htmlspecialchars($g['last_viewed']) ?></p>
                                            <?php endif; ?>
                                        </div>

                                        <div class="flex flex-wrap items-center gap-2 shrink-0">
                                            <button type="button" onclick="toggleGuestEditor('edit-box-<?= $idx ?>')" class="px-2.5 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 text-xs font-semibold transition cursor-pointer">
                                                Edit Events
                                            </button>
                                            <button type="button" onclick="copyInviteLink('<?= htmlspecialchars($guestLink, ENT_QUOTES) ?>', this)" class="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold transition cursor-pointer">
                                                Copy Link
                                            </button>
                                            <a href="https://wa.me/?text=<?= $waText ?>" target="_blank" rel="noopener noreferrer" class="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition">
                                                WhatsApp
                                            </a>
                                            <form method="POST" onsubmit="return confirm('Revoke and delete this guest link?');" class="inline">
                                                <input type="hidden" name="form_action" value="delete_guest">
                                                <input type="hidden" name="token" value="<?= htmlspecialchars($g['token']) ?>">
                                                <button type="submit" class="px-2.5 py-1.5 rounded-lg bg-red-500/15 hover:bg-red-500/30 text-red-300 text-xs transition cursor-pointer" title="Revoke Link">
                                                    ✕
                                                </button>
                                            </form>
                                        </div>
                                    </div>

                                    <!-- Collapsible Inline Event Permission Editor -->
                                    <form id="edit-box-<?= $idx ?>" method="POST" class="hidden pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
                                        <input type="hidden" name="form_action" value="update_guest_events">
                                        <input type="hidden" name="token" value="<?= htmlspecialchars($g['token']) ?>">
                                        <div class="flex flex-wrap gap-3">
                                            <?php foreach (($config['events'] ?? []) as $ev): ?>
                                                <?php $checked = ($gAllowed === null) || in_array($ev['id'], $gAllowed, true); ?>
                                                <label class="flex items-center gap-1.5 text-xs text-stone-200 cursor-pointer">
                                                    <input type="checkbox" name="guest_events[]" value="<?= htmlspecialchars($ev['id']) ?>" <?= $checked ? 'checked' : '' ?> class="w-3.5 h-3.5 rounded accent-amber-500">
                                                    <span><?= htmlspecialchars($ev['title']) ?></span>
                                                </label>
                                            <?php endforeach; ?>
                                        </div>
                                        <button type="submit" class="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold cursor-pointer">
                                            Save Changes
                                        </button>
                                    </form>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        <?php elseif ($activeTab === 'rsvps'): ?>
            <div class="space-y-6">
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div class="p-5 rounded-2xl bg-[#1C2019] border border-white/10">
                        <p class="text-xs text-stone-400 uppercase tracking-wider">Confirmed Headcount</p>
                        <p class="text-3xl font-bold text-emerald-400 mt-1"><?= $attendingGuests ?></p>
                    </div>
                    <div class="p-5 rounded-2xl bg-[#1C2019] border border-white/10">
                        <p class="text-xs text-stone-400 uppercase tracking-wider">Unable to Attend</p>
                        <p class="text-3xl font-bold text-rose-400 mt-1"><?= $declinedCount ?></p>
                    </div>
                    <div class="p-5 rounded-2xl bg-[#1C2019] border border-white/10">
                        <p class="text-xs text-stone-400 uppercase tracking-wider">Total Responses</p>
                        <p class="text-3xl font-bold text-amber-400 mt-1"><?= count($rsvps) ?></p>
                    </div>
                </div>

                <div class="bg-[#1C2019] border border-white/10 rounded-2xl p-6">
                    <h2 class="text-lg font-semibold text-amber-400 mb-4">Guest RSVPs &amp; Wishes</h2>
                    <?php if (empty($rsvps)): ?>
                        <p class="text-sm text-stone-400 py-8 text-center">No RSVP responses submitted yet.</p>
                    <?php else: ?>
                        <div class="space-y-3">
                            <?php foreach (array_reverse($rsvps) as $r): ?>
                                <div class="p-4 rounded-xl bg-black/25 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                    <div>
                                        <div class="flex flex-wrap items-center gap-2">
                                            <span class="font-semibold text-white"><?= htmlspecialchars($r['name']) ?></span>
                                            <span class="px-2.5 py-0.5 rounded-full text-[11px] font-semibold <?= ($r['status'] ?? '') === 'Joyfully Attending' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300' ?>">
                                                <?= htmlspecialchars($r['status']) ?> (<?= (int)$r['guests'] ?>)
                                            </span>
                                            <span class="text-xs text-stone-500"><?= htmlspecialchars($r['created_at'] ?? '') ?></span>
                                        </div>
                                        <?php if (!empty($r['message'])): ?>
                                            <p class="text-sm text-stone-300 mt-2 italic">"<?= htmlspecialchars($r['message']) ?>"</p>
                                        <?php endif; ?>
                                    </div>
                                    <form method="POST" onsubmit="return confirm('Delete this RSVP entry?');">
                                        <input type="hidden" name="form_action" value="delete_rsvp">
                                        <input type="hidden" name="rsvp_id" value="<?= htmlspecialchars($r['id']) ?>">
                                        <button type="submit" class="px-3 py-1.5 rounded-lg bg-red-500/15 hover:bg-red-500/30 text-red-300 text-xs cursor-pointer">Delete</button>
                                    </form>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

    </main>

    <script>
        function toggleAllCreateEvents(state) {
            document.querySelectorAll('.create-event-cb').forEach(cb => cb.checked = state);
        }

        function toggleGuestEditor(id) {
            const el = document.getElementById(id);
            if (el) el.classList.toggle('hidden');
        }

        function copyInviteLink(url, btn) {
            navigator.clipboard.writeText(url).then(function() {
                const orig = btn.textContent;
                btn.textContent = 'Copied!';
                btn.classList.add('bg-emerald-600', 'text-white');
                setTimeout(function() {
                    btn.textContent = orig;
                    btn.classList.remove('bg-emerald-600', 'text-white');
                }, 1600);
            });
        }

        function addEventRow() {
            const randId = 'ev_' + Math.random().toString(36).substring(2, 10);
            const html = `
                <div class="p-4 rounded-xl bg-black/25 border border-white/10 space-y-3 relative event-row">
                    <input type="hidden" name="event_id[]" value="${randId}">
                    <button type="button" onclick="this.parentElement.remove()" class="absolute top-3 right-3 text-xs text-red-400 hover:underline">Remove</button>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <input type="text" name="event_title[]" placeholder="Event Title" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                        <input type="text" name="event_date[]" placeholder="Date" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                        <input type="text" name="event_time[]" placeholder="Time" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <input type="text" name="event_venue[]" placeholder="Venue Address" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                        <input type="text" name="event_dress[]" placeholder="Dress Code" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                        <input type="url" name="event_map[]" placeholder="Google Maps URL" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                    </div>
                </div>`;
            document.getElementById('events-container').insertAdjacentHTML('beforeend', html);
        }

        function addContactRow() {
            const html = `
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 items-center">
                    <input type="text" name="contact_name[]" placeholder="Name / Relation" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                    <input type="text" name="contact_phone[]" placeholder="+8801XXXXXXXXX" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                    <button type="button" onclick="this.parentElement.remove()" class="text-xs text-red-400 hover:underline text-left sm:text-center">Remove</button>
                </div>`;
            document.getElementById('contacts-container').insertAdjacentHTML('beforeend', html);
        }
    </script>
</body>
</html>
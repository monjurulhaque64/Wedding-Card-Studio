<?php
// ==========================================
// ROYAL MUGHAL IVORY WEDDING INVITATION (index.php)
// Event-Wise Guest Access Filtering + Mughal Ivory Envelope
// ==========================================

header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');

$configFile = __DIR__ . '/config.json';
$guestsFile = __DIR__ . '/guests.json';
$rsvpsFile  = __DIR__ . '/rsvps.json';

$defaultConfig = [
    'bismillah_arabic' => 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ',
    'bismillah_text'   => 'In the name of Allah, the Most Gracious, the Most Merciful',
    'monogram'         => 'A & R',
    'bride_name'       => 'Ayesha Siddiqua',
    'groom_name'       => 'Rahim Uddin',
    'tagline'          => 'Two souls, one beautiful journey — begun with blessings',
    'parents_text'     => 'Together with their beloved parents, Mr. & Mrs. Abdul Karim and Mr. & Mrs. Nurul Islam',
    'invite_message'   => 'We joyfully request the honor of your presence and prayers as we unite in marriage and celebrate the beginning of our new life together.',
    'wedding_date'     => '2027-02-12T17:00:00',
    'date_display'     => 'FRIDAY, 12 FEBRUARY 2027 • 5:00 PM',
    'music_url'        => '',
    'theme'            => 'olive_gold',
    'font_preset'      => 'royal_editorial',
    'custom_colors'    => [
        'envelope' => '#F2E6CE',
        'bg'       => '#1D1812',
        'surface'  => '#FCF8F0',
        'accent'   => '#B88928',
        'text'     => '#2A2115'
    ],
    'events' => [
        [
            'id'         => 'ev_holud',
            'title'      => 'Gaye Holud & Mehendi',
            'date'       => 'Wednesday, 10 February 2027',
            'time'       => '6:30 PM Onwards',
            'venue'      => 'Rose Garden Convention Hall, Dhaka',
            'dress_code' => 'Traditional Yellow, Mustard & Olive',
            'map_url'    => 'https://maps.google.com'
        ],
        [
            'id'         => 'ev_nikah',
            'title'      => 'Nikah & Wedding Ceremony',
            'date'       => 'Friday, 12 February 2027',
            'time'       => '5:00 PM – 10:30 PM',
            'venue'      => 'The Grand Ballroom, Sheraton Dhaka',
            'dress_code' => 'Formal Traditional / Festive Attire',
            'map_url'    => 'https://maps.google.com'
        ],
        [
            'id'         => 'ev_walima',
            'title'      => 'Walima Reception',
            'date'       => 'Sunday, 14 February 2027',
            'time'       => '7:00 PM Onwards',
            'venue'      => 'Army Golf Club, Dhaka Cantonment',
            'dress_code' => 'Elegant Evening Wear',
            'map_url'    => 'https://maps.google.com'
        ]
    ],
    'public_events' => null,
    'contacts' => [
        ['name' => 'Brother of Bride', 'phone' => '+8801700000000'],
        ['name' => 'Family Coordinator', 'phone' => '+8801800000000']
    ]
];

if (!file_exists($configFile)) {
    @file_put_contents($configFile, json_encode($defaultConfig, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
}
if (!file_exists($guestsFile)) {
    $sampleGuests = [
        [
            'token'          => 'mitu-84a2',
            'name'           => 'Mitu Apa & Family',
            'allowed_events' => null,
            'views'          => 0,
            'last_viewed'    => null
        ]
    ];
    @file_put_contents($guestsFile, json_encode($sampleGuests, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
}
if (!file_exists($rsvpsFile)) {
    @file_put_contents($rsvpsFile, json_encode([], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
}

$loadedConfig = file_exists($configFile) ? json_decode(@file_get_contents($configFile), true) : null;
$config = is_array($loadedConfig) ? array_merge($defaultConfig, $loadedConfig) : $defaultConfig;

// Ensure consistent Event IDs matching admin.php
if (!empty($config['events']) && is_array($config['events'])) {
    foreach ($config['events'] as $i => &$ev) {
        if (empty($ev['id'])) {
            $ev['id'] = 'ev_' . substr(md5(($ev['title'] ?? 'event') . '_' . $i), 0, 8);
        }
    }
    unset($ev);
}

// Handle AJAX RSVP Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['action']) && $_GET['action'] === 'rsvp') {
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input || empty(trim($input['name'] ?? ''))) {
        echo json_encode(['success' => false, 'message' => 'Please enter your name.']);
        exit;
    }

    $rsvps = file_exists($rsvpsFile) ? (json_decode(@file_get_contents($rsvpsFile), true) ?: []) : [];
    $rsvps[] = [
        'id'         => uniqid('rsvp_'),
        'name'       => htmlspecialchars(trim($input['name']), ENT_QUOTES, 'UTF-8'),
        'status'     => ($input['status'] ?? 'attending') === 'declined' ? 'Unable to Attend' : 'Joyfully Attending',
        'guests'     => max(1, min(15, (int)($input['guests'] ?? 1))),
        'message'    => htmlspecialchars(trim($input['message'] ?? ''), ENT_QUOTES, 'UTF-8'),
        'token'      => preg_replace('/[^a-zA-Z0-9\-]/', '', $input['token'] ?? ''),
        'created_at' => date('d M Y, h:i A')
    ];

    @file_put_contents($rsvpsFile, json_encode($rsvps, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
    echo json_encode(['success' => true]);
    exit;
}

// Tamper-Proof Guest Lookup via ?to=token
$guestName          = 'Honored Guest';
$isVerified         = false;
$verifiedToken      = '';
$guestAllowedEvents = null; // null = all events

if (!empty($_GET['to']) && file_exists($guestsFile)) {
    $rawToken = preg_replace('/[^a-zA-Z0-9\-]/', '', $_GET['to']);
    $guests   = json_decode(@file_get_contents($guestsFile), true) ?: [];
    $updated  = false;

    foreach ($guests as &$g) {
        if (isset($g['token']) && hash_equals((string)$g['token'], (string)$rawToken)) {
            $guestName          = htmlspecialchars($g['name'], ENT_QUOTES, 'UTF-8');
            $isVerified         = true;
            $verifiedToken      = $g['token'];
            $guestAllowedEvents = array_key_exists('allowed_events', $g) ? $g['allowed_events'] : null;
            $g['views']         = ($g['views'] ?? 0) + 1;
            $g['last_viewed']   = date('d M Y, h:i A');
            $updated            = true;
            break;
        }
    }
    unset($g);

    if ($updated) {
        @file_put_contents($guestsFile, json_encode($guests, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
    }
}

// Filter Visible Events Based on Guest Token or Public Default
$allEvents = $config['events'] ?? [];
if ($isVerified) {
    if (is_array($guestAllowedEvents)) {
        $visibleEvents = array_values(array_filter($allEvents, function ($ev) use ($guestAllowedEvents) {
            return in_array($ev['id'], $guestAllowedEvents, true);
        }));
    } else {
        $visibleEvents = $allEvents;
    }
} else {
    $pubAllowed = $config['public_events'] ?? null;
    if (is_array($pubAllowed)) {
        $visibleEvents = array_values(array_filter($allEvents, function ($ev) use ($pubAllowed) {
            return in_array($ev['id'], $pubAllowed, true);
        }));
    } else {
        $visibleEvents = $allEvents;
    }
}

// Smart Header Date Display: if invited to only 1 specific event, display that event's date & time
$heroDateDisplay = $config['date_display'] ?? '';
if (count($visibleEvents) === 1) {
    $onlyEv = $visibleEvents[0];
    $heroDateDisplay = strtoupper(trim(($onlyEv['date'] ?? '') . (!empty($onlyEv['time']) ? ' • ' . $onlyEv['time'] : '')));
}

$themes = [
    'olive_gold'          => ['bg' => '#1D1812', 'surface' => '#FCF8F0', 'accent' => '#B88928', 'text' => '#2A2115', 'is_dark' => false],
    'emerald_gold'        => ['bg' => '#042219', 'surface' => '#083E2F', 'accent' => '#D4AF37', 'text' => '#F7F3E8', 'is_dark' => true],
    'maroon_cream'        => ['bg' => '#36080F', 'surface' => '#FCF6EC', 'accent' => '#B8862D', 'text' => '#380E14', 'is_dark' => false],
    'dusty_rose'          => ['bg' => '#421F29', 'surface' => '#FEF7F7', 'accent' => '#B87684', 'text' => '#3B1E26', 'is_dark' => false],
    'midnight_navy'       => ['bg' => '#071221', 'surface' => '#0D1E36', 'accent' => '#D6C08D', 'text' => '#F1F5F9', 'is_dark' => true],
    'ivory_terracotta'    => ['bg' => '#241B14', 'surface' => '#FCF8F2', 'accent' => '#B55B3C', 'text' => '#2C201A', 'is_dark' => false],
    'sage_brass'          => ['bg' => '#1F2B21', 'surface' => '#F7F8F3', 'accent' => '#B68F40', 'text' => '#202B22', 'is_dark' => false],
    'obsidian_rosegold'   => ['bg' => '#0E0D0F', 'surface' => '#171518', 'accent' => '#E2A796', 'text' => '#F5ECEA', 'is_dark' => true],
    'aubergine_champagne' => ['bg' => '#210920', 'surface' => '#30102F', 'accent' => '#E5C382', 'text' => '#FAF4E8', 'is_dark' => true],
    'peacock_saffron'     => ['bg' => '#052F38', 'surface' => '#F8FAFA', 'accent' => '#D18F19', 'text' => '#0A3640', 'is_dark' => false]
];

$selectedThemeKey = $config['theme'] ?? 'olive_gold';
if ($selectedThemeKey === 'custom' && !empty($config['custom_colors'])) {
    $c   = $config['custom_colors'];
    $hex = ltrim($c['surface'], '#');
    $r   = hexdec(substr($hex, 0, 2));
    $g   = hexdec(substr($hex, 2, 2));
    $b   = hexdec(substr($hex, 4, 2));
    $lum = (0.299 * $r + 0.587 * $g + 0.114 * $b) / 255;
    $palette = [
        'bg'      => $c['bg'],
        'surface' => $c['surface'],
        'accent'  => $c['accent'],
        'text'    => $c['text'],
        'is_dark' => $lum < 0.5
    ];
} else {
    $palette = $themes[$selectedThemeKey] ?? $themes['olive_gold'];
}

$fontPresets = [
    'royal_editorial'    => ['display' => "'Cinzel', serif", 'serif' => "'Cormorant Garamond', serif", 'sans' => "'Plus Jakarta Sans', sans-serif"],
    'classic_aristocrat' => ['display' => "'Playfair Display', serif", 'serif' => "'Lora', serif", 'sans' => "'Plus Jakarta Sans', sans-serif"],
    'modern_luxury'      => ['display' => "'Montserrat', sans-serif", 'serif' => "'Cormorant Garamond', serif", 'sans' => "'Plus Jakarta Sans', sans-serif"]
];
$fonts = $fontPresets[$config['font_preset'] ?? 'royal_editorial'] ?? $fontPresets['royal_editorial'];

$pageTitle = ($isVerified ? "Invitation for {$guestName} — " : "Wedding Invitation — ")
           . htmlspecialchars($config['bride_name']) . " & " . htmlspecialchars($config['groom_name']);
$ogDesc = "You are cordially invited to celebrate the wedding of "
        . htmlspecialchars($config['bride_name']) . " & " . htmlspecialchars($config['groom_name']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    <meta property="og:title" content="<?= $pageTitle ?>">
    <meta property="og:description" content="<?= $ogDesc ?>">
    <meta property="og:type" content="website">

    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Cinzel:wght@500;600;700&family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,600;1,700&family=Great+Vibes&family=Lora:ital,wght@0,400;0,600;1,400&family=Montserrat:wght@400;500;600&family=Plus+Jakarta+Sans:wght@400;500;600&family=Playfair+Display:ital,wght@0,500;0,600;0,700;1,500&display=swap" rel="stylesheet">

    <style>
        :root {
            --bg-outer: <?= htmlspecialchars($palette['bg']) ?>;
            --card-surface: <?= htmlspecialchars($palette['surface']) ?>;
            --accent-color: <?= htmlspecialchars($palette['accent']) ?>;
            --text-main: <?= htmlspecialchars($palette['text']) ?>;
            --font-display: <?= $fonts['display'] ?>;
            --font-serif: <?= $fonts['serif'] ?>;
            --font-sans: <?= $fonts['sans'] ?>;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            background-color: var(--bg-outer);
            background-image:
                radial-gradient(circle at 50% 0%, rgba(212, 175, 55, 0.14) 0%, transparent 60%),
                radial-gradient(circle at 50% 100%, rgba(0, 0, 0, 0.55) 0%, transparent 70%);
            color: var(--text-main);
            font-family: var(--font-sans);
            overflow-x: hidden;
        }

        body.envelope-locked {
            overflow: hidden;
            height: 100dvh;
        }

        .font-display { font-family: var(--font-display); }
        .font-serif-editorial { font-family: var(--font-serif); }
        .font-arabic { font-family: 'Amiri', serif; }

        /* STAGE 1: MUGHAL IVORY EMBOSSED COTTON ENVELOPE */
        #envelope-stage {
            position: fixed;
            inset: 0;
            z-index: 60;
            display: flex;
            align-items: center;
            justify-content: center;
            background:
                radial-gradient(circle at 50% 45%, rgba(235, 200, 115, 0.16) 0%, rgba(12, 10, 8, 0.85) 100%),
                var(--bg-outer);
            transition: opacity 1s cubic-bezier(0.22, 1, 0.36, 1), transform 1.2s cubic-bezier(0.22, 1, 0.36, 1);
            perspective: 2000px;
        }

        #envelope-stage.stage-fade-out {
            opacity: 0;
            transform: scale(1.08);
            pointer-events: none;
        }

        .envelope-shell {
            position: relative;
            width: 100%;
            height: 100dvh;
            max-width: 450px;
            max-height: 830px;
            background-color: #EFE3CA;
            overflow: hidden;
            cursor: pointer;
            box-shadow:
                0 40px 100px rgba(0, 0, 0, 0.75),
                0 0 0 1px rgba(212, 175, 55, 0.38);
            transform-style: preserve-3d;
            transition: transform 0.25s ease-out;
            user-select: none;
            -webkit-tap-highlight-color: transparent;
        }

        @media (min-width: 640px) {
            .envelope-shell {
                height: 91vh;
                border-radius: 26px;
            }
        }

        .ivory-cotton-paper {
            background-color: #F3E7CE;
            background-image:
                radial-gradient(circle at 50% 35%, rgba(255, 252, 244, 0.72) 0%, rgba(238, 222, 190, 0.45) 60%, rgba(214, 192, 152, 0.68) 100%);
        }

        .ivory-cotton-paper::after {
            content: "";
            position: absolute;
            inset: 0;
            opacity: 0.42;
            pointer-events: none;
            mix-blend-mode: multiply;
            background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 240 240' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='cottonFiber'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.065' numOctaves='4' seed='12' stitchTiles='stitch'/%3E%3CfeDiffuseLighting in='noise' lighting-color='%23fffaf0' surfaceScale='1.4'%3E%3CfeDistantLight azimuth='45' elevation='62'/%3E%3C/feDiffuseLighting%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23cottonFiber)'/%3E%3C/svg%3E");
        }

        .envelope-interior {
            position: absolute;
            inset: 0;
            background-color: #EADAC0;
            background-image: url("data:image/svg+xml,%3Csvg width='68' height='68' viewBox='0 0 68 68' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' stroke='%23b5872a' stroke-opacity='0.28' stroke-width='0.95'%3E%3Cpath d='M34 5C38 20 48 30 63 34C48 38 38 48 34 63C30 48 20 38 5 34C20 30 30 20 34 5Z'/%3E%3Ccircle cx='34' cy='34' r='10'/%3E%3Ccircle cx='34' cy='34' r='2.5'/%3E%3C/g%3E%3C/svg%3E");
            box-shadow: inset 0 26px 50px rgba(85, 62, 28, 0.35);
            z-index: 1;
        }

        .inner-rising-card {
            position: absolute;
            left: 5.5%;
            right: 5.5%;
            top: 9%;
            bottom: 4%;
            background: var(--card-surface);
            color: var(--text-main);
            border-radius: 18px;
            border: 2px solid color-mix(in srgb, var(--accent-color) 72%, transparent);
            box-shadow: 0 -8px 35px rgba(72, 52, 22, 0.28);
            z-index: 2;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            padding: 2rem 1.25rem;
            text-align: center;
            transform: translateY(16%) scale(0.94);
            transition: transform 1.35s cubic-bezier(0.22, 1, 0.36, 1), box-shadow 1.35s ease;
        }

        .envelope-shell.is-opening .inner-rising-card {
            transform: translateY(-22%) scale(1.05);
            box-shadow: 0 28px 65px rgba(45, 32, 12, 0.45);
        }

        .flap-left-wrap {
            position: absolute;
            inset: 0;
            z-index: 3;
            filter: drop-shadow(5px 0 12px rgba(82, 58, 24, 0.26));
            pointer-events: none;
        }
        .flap-left {
            width: 100%;
            height: 100%;
            clip-path: polygon(0 6%, 50% 48%, 0 92%);
        }

        .flap-right-wrap {
            position: absolute;
            inset: 0;
            z-index: 3;
            filter: drop-shadow(-5px 0 12px rgba(82, 58, 24, 0.26));
            pointer-events: none;
        }
        .flap-right {
            width: 100%;
            height: 100%;
            clip-path: polygon(100% 6%, 50% 48%, 100% 92%);
        }

        .flap-bottom-wrap {
            position: absolute;
            inset: 0;
            z-index: 4;
            filter: drop-shadow(0 -8px 18px rgba(82, 58, 24, 0.28));
            pointer-events: none;
        }
        .flap-bottom {
            width: 100%;
            height: 100%;
            clip-path: polygon(0 91%, 50% 47%, 100% 91%, 100% 100%, 0 100%);
        }

        .flap-top-pivot {
            position: absolute;
            inset: 0;
            z-index: 6;
            transform-origin: top center;
            transform-style: preserve-3d;
            transition: transform 1.35s cubic-bezier(0.38, 0.02, 0.18, 1);
            filter: drop-shadow(0 12px 20px rgba(74, 52, 20, 0.36));
        }

        .envelope-shell.is-opening .flap-top-pivot {
            transform: rotateX(180deg);
        }

        .envelope-shell.flap-behind .flap-top-pivot {
            z-index: 1;
            filter: none;
        }

        .flap-top-front,
        .flap-top-back {
            position: absolute;
            inset: 0;
            clip-path: polygon(0 0, 100% 0, 100% 13%, 50% 49%, 0 13%);
            -webkit-backface-visibility: hidden;
            backface-visibility: hidden;
        }

        .flap-top-back {
            background-color: #EFE2C8;
            background-image: url("data:image/svg+xml,%3Csvg width='68' height='68' viewBox='0 0 68 68' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' stroke='%23b5872a' stroke-opacity='0.26' stroke-width='0.95'%3E%3Cpath d='M34 5C38 20 48 30 63 34C48 38 38 48 34 63C30 48 20 38 5 34C20 30 30 20 34 5Z'/%3E%3Ccircle cx='34' cy='34' r='10'/%3E%3C/g%3E%3C/svg%3E");
            transform: rotateX(180deg);
        }

        .wax-seal-wrapper {
            position: absolute;
            top: 48%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 9;
            width: 112px;
            height: 112px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: transform 0.7s cubic-bezier(0.34, 1.56, 0.64, 1), opacity 0.55s ease;
        }

        .envelope-shell.seal-broken .wax-seal-wrapper {
            transform: translate(-50%, -50%) scale(1.48) rotate(20deg);
            opacity: 0;
            pointer-events: none;
        }

        @keyframes sealGlowPulse {
            0%, 100% {
                transform: scale(1);
                filter: drop-shadow(0 12px 18px rgba(68, 46, 12, 0.45));
            }
            50% {
                transform: scale(1.045);
                filter: drop-shadow(0 16px 24px rgba(68, 46, 12, 0.52)) drop-shadow(0 0 14px rgba(212, 165, 58, 0.5));
            }
        }

        .wax-seal-svg {
            width: 100%;
            height: 100%;
            animation: sealGlowPulse 2.6s ease-in-out infinite;
        }

        .guest-emboss-area {
            position: absolute;
            bottom: 8.5%;
            left: 50%;
            transform: translateX(-50%);
            width: 82%;
            text-align: center;
            z-index: 8;
            pointer-events: none;
        }

        .guest-gold-letterpress {
            font-family: 'Cormorant Garamond', serif;
            font-style: italic;
            font-weight: 700;
            font-size: clamp(1.45rem, 4.8vw, 1.85rem);
            color: #5C4012;
            text-shadow: 0 1px 0 rgba(255, 253, 246, 0.9);
            letter-spacing: 0.02em;
        }

        @keyframes tapFloat {
            0%, 100% { opacity: 0.68; transform: translateY(0); }
            50% { opacity: 1; transform: translateY(-2px); }
        }
        .tap-hint { animation: tapFloat 2.1s ease-in-out infinite; }

        /* STAGE 2: ORNATE ROYAL WEDDING CARD */
        .royal-card {
            background-color: var(--card-surface);
            color: var(--text-main);
            border: 2px solid color-mix(in srgb, var(--accent-color) 65%, transparent);
            box-shadow:
                0 30px 90px rgba(0, 0, 0, 0.45),
                0 0 40px color-mix(in srgb, var(--accent-color) 18%, transparent);
            position: relative;
        }

        .royal-inner-frame {
            position: absolute;
            inset: 10px;
            border: 1px solid color-mix(in srgb, var(--accent-color) 45%, transparent);
            border-radius: 20px;
            pointer-events: none;
            z-index: 2;
        }

        @media (min-width: 640px) {
            .royal-inner-frame {
                inset: 16px;
            }
        }

        @keyframes goldFoilSweep {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .gold-foil-title {
            background: linear-gradient(
                120deg,
                var(--accent-color) 0%,
                #E8C66A 25%,
                var(--accent-color) 50%,
                #F5DC8E 75%,
                var(--accent-color) 100%
            );
            background-size: 220% auto;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: goldFoilSweep 6s ease-in-out infinite;
        }

        .gold-divider {
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--accent-color), transparent);
        }

        .accent-text { color: var(--accent-color); }
        .accent-border { border-color: color-mix(in srgb, var(--accent-color) 42%, transparent); }
        .accent-bg { background-color: var(--accent-color); }

        .event-royal-box {
            position: relative;
            border: 1px solid color-mix(in srgb, var(--accent-color) 45%, transparent);
            background: linear-gradient(180deg, color-mix(in srgb, var(--accent-color) 5%, transparent) 0%, transparent 100%);
            transition: transform 0.35s cubic-bezier(0.22, 1, 0.36, 1), box-shadow 0.35s ease, border-color 0.35s ease;
        }

        .event-royal-box:hover {
            transform: translateY(-4px);
            border-color: var(--accent-color);
            box-shadow: 0 14px 32px color-mix(in srgb, var(--accent-color) 18%, transparent);
        }

        .reveal-block {
            opacity: 0;
            transform: translateY(24px);
            transition: opacity 0.85s cubic-bezier(0.22, 1, 0.36, 1), transform 0.85s cubic-bezier(0.22, 1, 0.36, 1);
        }

        .reveal-block.is-visible {
            opacity: 1;
            transform: translateY(0);
        }

        .btn-luxury {
            background: linear-gradient(135deg, var(--accent-color) 0%, color-mix(in srgb, var(--accent-color) 82%, #000) 100%);
            color: <?= $palette['is_dark'] ? '#111111' : '#FFFFFF' ?>;
            transition: all 0.3s ease;
        }
        .btn-luxury:hover {
            filter: brightness(1.08);
            transform: translateY(-2px);
            box-shadow: 0 10px 24px color-mix(in srgb, var(--accent-color) 38%, transparent);
        }

        #ambient-canvas {
            position: fixed;
            inset: 0;
            pointer-events: none;
            z-index: 45;
        }
    </style>
</head>
<body class="envelope-locked antialiased">

    <audio id="wedding-audio" preload="auto" playsinline></audio>
    <canvas id="ambient-canvas"></canvas>

    <!-- STAGE 1: MUGHAL IVORY EMBOSSED ENVELOPE -->
    <div id="envelope-stage">
        <div id="envelope-shell" class="envelope-shell" onclick="openEnvelope()" role="button" tabindex="0" aria-label="Tap Wax Seal to Unseal Invitation">

            <div class="envelope-interior"></div>

            <div class="inner-rising-card">
                <p class="text-[10px] uppercase tracking-[0.3em] accent-text font-semibold mb-1.5">Royal Wedding Invitation</p>
                <div class="w-12 h-12 rounded-full border accent-border flex items-center justify-center mb-2">
                    <span class="font-serif-editorial italic font-bold text-lg accent-text"><?= htmlspecialchars($config['monogram']) ?></span>
                </div>
                <h2 class="font-display text-xl sm:text-2xl tracking-wider uppercase leading-snug">
                    <?= htmlspecialchars($config['bride_name']) ?>
                    <span class="block text-sm italic font-serif-editorial accent-text my-0.5">&amp;</span>
                    <?= htmlspecialchars($config['groom_name']) ?>
                </h2>
                <div class="w-20 gold-divider my-3"></div>
                <p class="font-serif-editorial italic text-sm opacity-80">
                    <?= htmlspecialchars($heroDateDisplay) ?>
                </p>
            </div>

            <!-- LEFT FLAP WITH HAND-PAINTED MUGHAL FLORAL VINES -->
            <div class="flap-left-wrap">
                <div class="flap-left ivory-cotton-paper relative">
                    <svg class="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 450 840" preserveAspectRatio="none">
                        <defs>
                            <g id="mughalFlower">
                                <path d="M0 -18 C6 -12, 8 -4, 0 0 C-8 -4, -6 -12, 0 -18 Z" fill="#9E2A22" stroke="#D9A84E" stroke-width="0.6"/>
                                <path d="M16 -8 C14 0, 7 4, 0 0 C5 -7, 11 -11, 16 -8 Z" fill="#B6352A" stroke="#D9A84E" stroke-width="0.6"/>
                                <path d="M16 9 C9 12, 2 8, 0 0 C8 -1, 14 3, 16 9 Z" fill="#9E2A22" stroke="#D9A84E" stroke-width="0.6"/>
                                <path d="M0 18 C-6 12, -8 4, 0 0 C8 4, 6 12, 0 18 Z" fill="#B6352A" stroke="#D9A84E" stroke-width="0.6"/>
                                <path d="M-16 9 C-14 3, -8 -1, 0 0 C-2 8, -9 12, -16 9 Z" fill="#9E2A22" stroke="#D9A84E" stroke-width="0.6"/>
                                <path d="M-16 -8 C-11 -11, -5 -7, 0 0 C-7 4, -14 0, -16 -8 Z" fill="#B6352A" stroke="#D9A84E" stroke-width="0.6"/>
                                <circle cx="0" cy="0" r="6.5" fill="#D4743B" stroke="#F4D37E" stroke-width="0.8"/>
                                <circle cx="0" cy="0" r="3" fill="#F2CA63"/>
                            </g>
                            <g id="mughalLeaves">
                                <path d="M0 0 C8 -8, 18 -8, 22 -2 C15 3, 6 4, 0 0 Z" fill="#4E6338" stroke="#9C7A32" stroke-width="0.5"/>
                                <path d="M0 0 C-8 -8, -18 -8, -22 -2 C-15 3, -6 4, 0 0 Z" fill="#637846" stroke="#9C7A32" stroke-width="0.5"/>
                            </g>
                        </defs>

                        <path d="M 18 150 C 48 210, 12 275, 46 340 C 78 405, 16 470, 50 540 C 80 605, 18 670, 40 735"
                              fill="none" stroke="#8A6424" stroke-width="1.6" stroke-linecap="round"/>
                        <path d="M 35 230 C 75 245, 95 275, 108 305" fill="none" stroke="#8A6424" stroke-width="1.1"/>
                        <path d="M 46 365 C 92 380, 120 410, 134 442" fill="none" stroke="#8A6424" stroke-width="1.1"/>
                        <path d="M 48 510 C 88 525, 108 552, 118 580" fill="none" stroke="#8A6424" stroke-width="1.1"/>

                        <use href="#mughalLeaves" transform="translate(32, 200) rotate(22) scale(0.9)"/>
                        <use href="#mughalFlower" transform="translate(22, 160) scale(0.75)"/>
                        <use href="#mughalFlower" transform="translate(46, 265) scale(1.15)"/>
                        <use href="#mughalLeaves" transform="translate(86, 268) rotate(45) scale(0.85)"/>
                        <use href="#mughalFlower" transform="translate(108, 305) scale(0.72)"/>
                        <use href="#mughalLeaves" transform="translate(32, 335) rotate(-18) scale(0.95)"/>
                        <use href="#mughalFlower" transform="translate(62, 395) scale(1.2)"/>
                        <use href="#mughalLeaves" transform="translate(108, 405) rotate(40) scale(0.85)"/>
                        <use href="#mughalFlower" transform="translate(134, 442) scale(0.7)"/>
                        <use href="#mughalFlower" transform="translate(36, 485) scale(1.05)"/>
                        <use href="#mughalLeaves" transform="translate(85, 535) rotate(35) scale(0.9)"/>
                        <use href="#mughalFlower" transform="translate(52, 575) scale(1.18)"/>
                        <use href="#mughalFlower" transform="translate(28, 665) scale(0.95)"/>
                        <use href="#mughalLeaves" transform="translate(36, 705) rotate(15) scale(0.8)"/>

                        <polyline points="0,50 225,403 0,773" fill="none" stroke="#C59B38" stroke-width="1.3" stroke-opacity="0.55"/>
                    </svg>
                </div>
            </div>

            <!-- RIGHT FLAP WITH MIRRORED HAND-PAINTED MUGHAL FLORAL VINES -->
            <div class="flap-right-wrap">
                <div class="flap-right ivory-cotton-paper relative">
                    <svg class="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 450 840" preserveAspectRatio="none">
                        <g transform="translate(450, 0) scale(-1, 1)">
                            <path d="M 18 150 C 48 210, 12 275, 46 340 C 78 405, 16 470, 50 540 C 80 605, 18 670, 40 735"
                                  fill="none" stroke="#8A6424" stroke-width="1.6" stroke-linecap="round"/>
                            <path d="M 35 230 C 75 245, 95 275, 108 305" fill="none" stroke="#8A6424" stroke-width="1.1"/>
                            <path d="M 46 365 C 92 380, 120 410, 134 442" fill="none" stroke="#8A6424" stroke-width="1.1"/>
                            <path d="M 48 510 C 88 525, 108 552, 118 580" fill="none" stroke="#8A6424" stroke-width="1.1"/>

                            <use href="#mughalLeaves" transform="translate(32, 200) rotate(22) scale(0.9)"/>
                            <use href="#mughalFlower" transform="translate(22, 160) scale(0.75)"/>
                            <use href="#mughalFlower" transform="translate(46, 265) scale(1.15)"/>
                            <use href="#mughalLeaves" transform="translate(86, 268) rotate(45) scale(0.85)"/>
                            <use href="#mughalFlower" transform="translate(108, 305) scale(0.72)"/>
                            <use href="#mughalLeaves" transform="translate(32, 335) rotate(-18) scale(0.95)"/>
                            <use href="#mughalFlower" transform="translate(62, 395) scale(1.2)"/>
                            <use href="#mughalLeaves" transform="translate(108, 405) rotate(40) scale(0.85)"/>
                            <use href="#mughalFlower" transform="translate(134, 442) scale(0.7)"/>
                            <use href="#mughalFlower" transform="translate(36, 485) scale(1.05)"/>
                            <use href="#mughalLeaves" transform="translate(85, 535) rotate(35) scale(0.9)"/>
                            <use href="#mughalFlower" transform="translate(52, 575) scale(1.18)"/>
                            <use href="#mughalFlower" transform="translate(28, 665) scale(0.95)"/>
                            <use href="#mughalLeaves" transform="translate(36, 705) rotate(15) scale(0.8)"/>

                            <polyline points="0,50 225,403 0,773" fill="none" stroke="#C59B38" stroke-width="1.3" stroke-opacity="0.55"/>
                        </g>
                    </svg>
                </div>
            </div>

            <!-- BOTTOM CREAM POCKET FLAP -->
            <div class="flap-bottom-wrap">
                <div class="flap-bottom ivory-cotton-paper relative">
                    <svg class="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 450 840" preserveAspectRatio="none">
                        <polyline points="0,764 225,395 450,764" fill="none" stroke="#C59B38" stroke-width="1.3" stroke-opacity="0.5"/>
                    </svg>
                </div>
            </div>

            <!-- TOP V-FLAP WITH BLIND-EMBOSSED BOTANICAL CORNERS & SCALLOPED GOLD TRIM -->
            <div class="flap-top-pivot">
                <div class="flap-top-front ivory-cotton-paper relative">
                    <svg class="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 450 840" preserveAspectRatio="none">
                        <defs>
                            <linearGradient id="goldFoilTrim" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" stop-color="#D4AF37"/>
                                <stop offset="30%" stop-color="#F7DF8B"/>
                                <stop offset="55%" stop-color="#A87A1E"/>
                                <stop offset="80%" stop-color="#F3D678"/>
                                <stop offset="100%" stop-color="#B58624"/>
                            </linearGradient>

                            <g id="embossedBranch">
                                <path d="M 0 0 Q 32 45, 78 72" fill="none" stroke="#C4AE84" stroke-width="1.4"/>
                                <path d="M 0 -1 Q 32 44, 78 71" fill="none" stroke="#FFFDF8" stroke-width="1"/>
                                <path d="M 14 16 C 24 8, 36 10, 38 16 C 30 20, 20 20, 14 16 Z" fill="#EFE2C7" stroke="#C4AE84" stroke-width="0.8"/>
                                <path d="M 14 16 C 8 28, 12 38, 18 40 C 21 32, 19 22, 14 16 Z" fill="#EFE2C7" stroke="#C4AE84" stroke-width="0.8"/>
                                <path d="M 32 36 C 44 28, 56 30, 58 36 C 50 40, 40 40, 32 36 Z" fill="#EFE2C7" stroke="#C4AE84" stroke-width="0.8"/>
                                <path d="M 32 36 C 26 48, 30 58, 36 60 C 39 52, 37 42, 32 36 Z" fill="#EFE2C7" stroke="#C4AE84" stroke-width="0.8"/>
                                <path d="M 52 54 C 64 46, 76 48, 78 54 C 70 58, 60 58, 52 54 Z" fill="#EFE2C7" stroke="#C4AE84" stroke-width="0.8"/>
                                <path d="M 52 54 C 46 66, 50 76, 56 78 C 59 70, 57 60, 52 54 Z" fill="#EFE2C7" stroke="#C4AE84" stroke-width="0.8"/>
                            </g>
                        </defs>

                        <use href="#embossedBranch" transform="translate(12, 22) scale(1.15)"/>
                        <use href="#embossedBranch" transform="translate(68, 8) rotate(22) scale(0.95)"/>
                        <g transform="translate(450, 0) scale(-1, 1)">
                            <use href="#embossedBranch" transform="translate(12, 22) scale(1.15)"/>
                            <use href="#embossedBranch" transform="translate(68, 8) rotate(22) scale(0.95)"/>
                        </g>

                        <polyline points="0,109 225,411 450,109" fill="none" stroke="url(#goldFoilTrim)" stroke-width="2.4"/>
                        <polyline points="0,101 225,403 450,101" fill="none" stroke="url(#goldFoilTrim)" stroke-width="0.9" stroke-opacity="0.65"/>

                        <path d="M 105 250 Q 112 276 130 283 Q 137 309 155 316 Q 162 342 180 349 Q 187 375 205 382"
                              fill="none" stroke="url(#goldFoilTrim)" stroke-width="1.9" stroke-linecap="round"/>
                        <path d="M 345 250 Q 338 276 320 283 Q 313 309 295 316 Q 288 342 270 349 Q 263 375 245 382"
                              fill="none" stroke="url(#goldFoilTrim)" stroke-width="1.9" stroke-linecap="round"/>
                    </svg>
                </div>
                <div class="flap-top-back"></div>
            </div>

            <!-- SCULPTED 3D MELTED GOLD WAX SEAL -->
            <div class="wax-seal-wrapper">
                <svg class="wax-seal-svg" viewBox="0 0 140 140">
                    <defs>
                        <radialGradient id="meltedGoldRim" cx="30%" cy="25%" r="75%">
                            <stop offset="0%" stop-color="#FFF5C0"/>
                            <stop offset="28%" stop-color="#E4B749"/>
                            <stop offset="68%" stop-color="#A67618"/>
                            <stop offset="90%" stop-color="#785008"/>
                            <stop offset="100%" stop-color="#B88725"/>
                        </radialGradient>

                        <radialGradient id="stampedInnerWell" cx="68%" cy="72%" r="70%">
                            <stop offset="0%" stop-color="#ECC256"/>
                            <stop offset="55%" stop-color="#C29028"/>
                            <stop offset="88%" stop-color="#8A5E0D"/>
                            <stop offset="100%" stop-color="#694506"/>
                        </radialGradient>

                        <linearGradient id="embossedLetterGold" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#FFF7CC"/>
                            <stop offset="45%" stop-color="#DFB042"/>
                            <stop offset="100%" stop-color="#7D5409"/>
                        </linearGradient>

                        <filter id="waxReliefShadow" x="-15%" y="-15%" width="130%" height="130%">
                            <feDropShadow dx="1" dy="2" stdDeviation="1.5" flood-color="#4A3003" flood-opacity="0.65"/>
                        </filter>
                    </defs>

                    <path d="M 70 8
                             C 84 7, 98 13, 109 22
                             C 120 31, 130 44, 132 59
                             C 134 74, 129 90, 120 103
                             C 111 116, 98 127, 83 131
                             C 68 135, 51 131, 38 123
                             C 25 115, 13 102, 9 87
                             C 5 72, 9 55, 17 41
                             C 25 27, 38 16, 53 11
                             C 59 9, 64 8, 70 8 Z"
                          fill="url(#meltedGoldRim)" stroke="#FFF0AD" stroke-width="1.4"/>

                    <path d="M 32 28 C 46 16, 65 12, 84 16" fill="none" stroke="#FFFBE0" stroke-width="2.6" stroke-linecap="round" opacity="0.75"/>

                    <circle cx="70" cy="70" r="44" fill="url(#stampedInnerWell)" stroke="#6B4706" stroke-width="2"/>
                    <circle cx="70" cy="70" r="41" fill="none" stroke="#FCE89C" stroke-width="0.9" opacity="0.75"/>

                    <path d="M 43 85 C 48 96, 58 102, 68 103" fill="none" stroke="#FCE694" stroke-width="1.2" stroke-linecap="round" opacity="0.85"/>
                    <path d="M 97 85 C 92 96, 82 102, 72 103" fill="none" stroke="#FCE694" stroke-width="1.2" stroke-linecap="round" opacity="0.85"/>
                    <circle cx="46" cy="90" r="1.6" fill="#FCE694"/>
                    <circle cx="52" cy="96" r="1.6" fill="#FCE694"/>
                    <circle cx="60" cy="100" r="1.6" fill="#FCE694"/>
                    <circle cx="94" cy="90" r="1.6" fill="#FCE694"/>
                    <circle cx="88" cy="96" r="1.6" fill="#FCE694"/>
                    <circle cx="80" cy="100" r="1.6" fill="#FCE694"/>

                    <text x="70" y="79" text-anchor="middle" filter="url(#waxReliefShadow)"
                          font-family="'Great Vibes', 'Cormorant Garamond', cursive"
                          font-weight="600" font-size="31" fill="url(#embossedLetterGold)" letter-spacing="1">
                        <?= htmlspecialchars($config['monogram']) ?>
                    </text>
                </svg>
            </div>

            <!-- LETTERPRESS GUEST NAME -->
            <div class="guest-emboss-area">
                <p class="text-[9.5px] uppercase tracking-[0.32em] text-[#8A6518] font-semibold mb-1">
                    Cordially Prepared For
                </p>
                <p class="guest-gold-letterpress leading-tight">
                    <?= $guestName ?>
                </p>
                <div class="w-24 h-[1px] bg-gradient-to-r from-transparent via-[#B88928]/55 to-transparent mx-auto my-2"></div>
                <p class="text-[9.5px] uppercase tracking-[0.26em] text-[#7A5814] font-semibold tap-hint">
                    Tap Wax Seal to Open
                </p>
            </div>

        </div>
    </div>

    <!-- FLOATING CONTROLS -->
    <div id="floating-controls" class="fixed top-4 right-4 z-50 flex items-center gap-2 opacity-0 pointer-events-none transition-opacity duration-500">
        <button onclick="replayEnvelope()" class="px-3.5 py-1.5 rounded-full text-xs font-medium tracking-wide backdrop-blur-md bg-black/60 text-amber-100 border border-amber-400/35 hover:bg-black/80 transition flex items-center gap-1.5 shadow-lg">
            <svg class="w-3.5 h-3.5 text-amber-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
            <span>Replay Envelope</span>
        </button>

        <button id="audio-toggle" onclick="toggleAudio()" title="Play / Mute Wedding Chime" class="w-8 h-8 rounded-full backdrop-blur-md bg-black/60 text-amber-200 border border-amber-400/35 hover:bg-black/80 transition flex items-center justify-center shadow-lg">
            <svg id="icon-sound-on" class="w-4 h-4 hidden" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"/></svg>
            <svg id="icon-sound-off" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15zM17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2"/></svg>
        </button>
    </div>

    <!-- STAGE 2: FULL ROYAL WEDDING CARD -->
    <main class="min-h-screen py-8 sm:py-14 px-3.5 sm:px-6 flex justify-center items-start">
        <article class="royal-card w-full max-w-2xl rounded-[28px] overflow-hidden">
            <div class="royal-inner-frame"></div>

            <!-- Top Royal Mughal Canopy Arch SVG -->
            <div class="w-full pt-5 px-6 sm:px-10 pointer-events-none relative z-10">
                <svg class="w-full h-20 sm:h-28 accent-text opacity-75" viewBox="0 0 600 130" fill="none" preserveAspectRatio="xMidYMid meet">
                    <path d="M20 125 C20 65, 140 55, 220 35 C265 24, 285 10, 300 4 C315 10, 335 24, 380 35 C460 55, 580 65, 580 125" stroke="currentColor" stroke-width="1.6"/>
                    <path d="M36 125 C36 75, 148 66, 225 47 C266 36, 286 22, 300 16 C314 22, 334 36, 375 47 C452 66, 564 75, 564 125" stroke="currentColor" stroke-width="0.9" stroke-dasharray="4 3"/>
                    <line x1="120" y1="53" x2="120" y2="86" stroke="currentColor" stroke-width="1"/>
                    <circle cx="120" cy="90" r="3.5" fill="currentColor"/>
                    <line x1="480" y1="53" x2="480" y2="86" stroke="currentColor" stroke-width="1"/>
                    <circle cx="480" cy="90" r="3.5" fill="currentColor"/>
                    <circle cx="300" cy="46" r="16" stroke="currentColor" stroke-width="1.2"/>
                    <path d="M300 24 L305 38 L319 46 L305 54 L300 68 L295 54 L281 46 L295 38 Z" stroke="currentColor" stroke-width="1"/>
                    <circle cx="300" cy="46" r="3" fill="currentColor"/>
                </svg>
            </div>

            <div class="px-6 sm:px-12 md:px-14 pb-12 sm:pb-16 -mt-4 relative z-10">

                <header class="text-center reveal-block">
                    <?php if (!empty($config['bismillah_arabic'])): ?>
                        <p class="font-arabic text-2xl sm:text-3xl accent-text mb-2 leading-relaxed">
                            <?= htmlspecialchars($config['bismillah_arabic']) ?>
                        </p>
                    <?php endif; ?>
                    <?php if (!empty($config['bismillah_text'])): ?>
                        <p class="font-serif-editorial italic text-sm sm:text-base opacity-80 max-w-md mx-auto">
                            <?= htmlspecialchars($config['bismillah_text']) ?>
                        </p>
                    <?php endif; ?>

                    <div class="flex items-center justify-center gap-3 my-6">
                        <span class="w-16 sm:w-24 gold-divider"></span>
                        <svg class="w-6 h-6 accent-text" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z"/>
                        </svg>
                        <span class="w-16 sm:w-24 gold-divider"></span>
                    </div>

                    <p class="text-[11px] sm:text-xs uppercase tracking-[0.32em] accent-text font-semibold mb-4">
                        With The Blessings Of Almighty, We Celebrate The Wedding Of
                    </p>

                    <h1 class="font-display text-3xl sm:text-5xl font-bold tracking-wider uppercase leading-tight gold-foil-title">
                        <?= htmlspecialchars($config['bride_name']) ?>
                    </h1>

                    <div class="my-3 flex items-center justify-center gap-4">
                        <span class="w-12 gold-divider"></span>
                        <span class="w-9 h-9 rounded-full border accent-border flex items-center justify-center font-serif-editorial italic text-xl accent-text">
                            &amp;
                        </span>
                        <span class="w-12 gold-divider"></span>
                    </div>

                    <h1 class="font-display text-3xl sm:text-5xl font-bold tracking-wider uppercase leading-tight gold-foil-title">
                        <?= htmlspecialchars($config['groom_name']) ?>
                    </h1>

                    <p class="font-serif-editorial italic text-base sm:text-lg opacity-85 mt-5">
                        “<?= htmlspecialchars($config['tagline']) ?>”
                    </p>

                    <?php if (!empty($heroDateDisplay)): ?>
                        <div class="mt-5 inline-block px-5 py-2 rounded-full border accent-border bg-black/[0.03]">
                            <p class="text-xs sm:text-sm font-semibold tracking-[0.22em] uppercase accent-text">
                                <?= htmlspecialchars($heroDateDisplay) ?>
                            </p>
                        </div>
                    <?php endif; ?>
                </header>

                <!-- Countdown -->
                <section class="my-10 p-5 sm:p-6 rounded-2xl border accent-border bg-black/[0.025] text-center reveal-block">
                    <p class="text-[10px] uppercase tracking-[0.28em] opacity-75 mb-3.5 font-semibold">Counting Down To Our Forever</p>
                    <div class="grid grid-cols-4 gap-2 sm:gap-4 max-w-md mx-auto">
                        <div class="p-3 rounded-xl border accent-border bg-white/[0.03] shadow-sm">
                            <span id="cd-days" class="font-display text-2xl sm:text-3xl font-bold accent-text block">00</span>
                            <span class="text-[10px] uppercase tracking-widest opacity-70">Days</span>
                        </div>
                        <div class="p-3 rounded-xl border accent-border bg-white/[0.03] shadow-sm">
                            <span id="cd-hours" class="font-display text-2xl sm:text-3xl font-bold accent-text block">00</span>
                            <span class="text-[10px] uppercase tracking-widest opacity-70">Hours</span>
                        </div>
                        <div class="p-3 rounded-xl border accent-border bg-white/[0.03] shadow-sm">
                            <span id="cd-mins" class="font-display text-2xl sm:text-3xl font-bold accent-text block">00</span>
                            <span class="text-[10px] uppercase tracking-widest opacity-70">Mins</span>
                        </div>
                        <div class="p-3 rounded-xl border accent-border bg-white/[0.03] shadow-sm">
                            <span id="cd-secs" class="font-display text-2xl sm:text-3xl font-bold accent-text block">00</span>
                            <span class="text-[10px] uppercase tracking-widest opacity-70">Secs</span>
                        </div>
                    </div>
                </section>

                <!-- Personalized Greeting -->
                <section class="text-center my-10 px-2 reveal-block">
                    <div class="inline-block mb-3">
                        <p class="font-serif-editorial text-2xl sm:text-3xl font-semibold">
                            Dear <span class="accent-text underline decoration-1 underline-offset-4"><?= $guestName ?></span>,
                        </p>
                    </div>
                    <p class="text-sm sm:text-base opacity-80 leading-relaxed mb-3 font-medium max-w-lg mx-auto">
                        <?= htmlspecialchars($config['parents_text']) ?>
                    </p>
                    <p class="font-serif-editorial text-lg sm:text-xl leading-relaxed opacity-95 max-w-lg mx-auto">
                        <?= htmlspecialchars($config['invite_message']) ?>
                    </p>
                </section>

                <?php if (!empty($visibleEvents)): ?>
                    <div class="flex items-center justify-center gap-3 my-10 reveal-block">
                        <span class="w-20 sm:w-32 gold-divider"></span>
                        <span class="w-2 h-2 rotate-45 accent-bg"></span>
                        <span class="w-3 h-3 rotate-45 border accent-border"></span>
                        <span class="w-2 h-2 rotate-45 accent-bg"></span>
                        <span class="w-20 sm:w-32 gold-divider"></span>
                    </div>

                    <!-- Filtered Wedding Events for This Guest -->
                    <section class="my-10 reveal-block">
                        <div class="text-center mb-8">
                            <p class="text-[11px] uppercase tracking-[0.3em] accent-text font-semibold mb-1.5">You Are Cordially Invited To</p>
                            <h2 class="font-display text-2xl sm:text-3xl font-semibold tracking-wide">
                                <?= count($visibleEvents) === 1 ? 'Ceremony Schedule' : 'Wedding Itinerary' ?>
                            </h2>
                        </div>

                        <div class="space-y-5">
                            <?php foreach ($visibleEvents as $event): ?>
                                <div class="event-royal-box p-5 sm:p-6 rounded-2xl">
                                    <span class="w-3 h-3 border-t-2 border-l-2 accent-border absolute top-2.5 left-2.5"></span>
                                    <span class="w-3 h-3 border-t-2 border-r-2 accent-border absolute top-2.5 right-2.5"></span>
                                    <span class="w-3 h-3 border-b-2 border-l-2 accent-border absolute bottom-2.5 left-2.5"></span>
                                    <span class="w-3 h-3 border-b-2 border-r-2 accent-border absolute bottom-2.5 right-2.5"></span>

                                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-3">
                                        <h3 class="font-display text-lg sm:text-xl font-semibold accent-text">
                                            <?= htmlspecialchars($event['title']) ?>
                                        </h3>
                                        <span class="text-xs font-semibold px-3 py-1 rounded-full border accent-border inline-block w-fit">
                                            <?= htmlspecialchars($event['time']) ?>
                                        </span>
                                    </div>

                                    <div class="space-y-1.5 text-sm opacity-90">
                                        <p class="flex items-center gap-2">
                                            <span class="accent-text font-semibold">Date:</span>
                                            <span><?= htmlspecialchars($event['date']) ?></span>
                                        </p>
                                        <p class="flex items-start gap-2">
                                            <span class="accent-text font-semibold">Venue:</span>
                                            <span><?= htmlspecialchars($event['venue']) ?></span>
                                        </p>
                                        <?php if (!empty($event['dress_code'])): ?>
                                            <p class="flex items-start gap-2">
                                                <span class="accent-text font-semibold">Dress Code:</span>
                                                <span><?= htmlspecialchars($event['dress_code']) ?></span>
                                            </p>
                                        <?php endif; ?>
                                    </div>

                                    <?php if (!empty($event['map_url'])): ?>
                                        <div class="mt-4 pt-3 border-t accent-border flex justify-end">
                                            <a href="<?= htmlspecialchars($event['map_url']) ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider accent-text hover:underline">
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                                                <span>View Venue on Google Maps</span>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </section>
                <?php endif; ?>

                <div class="flex items-center justify-center gap-3 my-10 reveal-block">
                    <span class="w-20 sm:w-32 gold-divider"></span>
                    <svg class="w-5 h-5 accent-text" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z"/>
                    </svg>
                    <span class="w-20 sm:w-32 gold-divider"></span>
                </div>

                <!-- RSVP Form -->
                <section class="my-10 reveal-block">
                    <div class="text-center mb-6">
                        <p class="text-[11px] uppercase tracking-[0.3em] accent-text font-semibold mb-1.5">Your Presence Is Our Greatest Gift</p>
                        <h2 class="font-display text-2xl sm:text-3xl font-semibold tracking-wide">RSVP &amp; Prayers</h2>
                    </div>

                    <form id="rsvp-form" class="space-y-4 max-w-lg mx-auto">
                        <div>
                            <label class="block text-xs uppercase tracking-wider opacity-80 mb-1.5">Guest Name *</label>
                            <input type="text" id="rsvp-name" required value="<?= $isVerified ? $guestName : '' ?>" placeholder="Enter your full name" class="w-full px-4 py-3 rounded-xl border accent-border bg-transparent focus:outline-none focus:ring-2 focus:ring-amber-500/40 text-sm">
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-xs uppercase tracking-wider opacity-80 mb-1.5">Attendance</label>
                                <select id="rsvp-status" class="w-full px-4 py-3 rounded-xl border accent-border bg-transparent focus:outline-none text-sm">
                                    <option value="attending" class="text-black">Joyfully Attending</option>
                                    <option value="declined" class="text-black">Unable to Attend</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-xs uppercase tracking-wider opacity-80 mb-1.5">Number of Guests</label>
                                <input type="number" id="rsvp-guests" min="1" max="15" value="1" class="w-full px-4 py-3 rounded-xl border accent-border bg-transparent focus:outline-none text-sm">
                            </div>
                        </div>

                        <div>
                            <label class="block text-xs uppercase tracking-wider opacity-80 mb-1.5">Blessings &amp; Wishes for the Couple</label>
                            <textarea id="rsvp-message" rows="3" placeholder="Write a warm prayer or blessing..." class="w-full px-4 py-3 rounded-xl border accent-border bg-transparent focus:outline-none text-sm"></textarea>
                        </div>

                        <button type="submit" id="rsvp-submit-btn" class="w-full py-3.5 rounded-xl font-semibold text-sm uppercase tracking-widest btn-luxury cursor-pointer">
                            Confirm RSVP &amp; Send Blessings
                        </button>
                    </form>

                    <div id="rsvp-success" class="hidden max-w-lg mx-auto p-6 rounded-2xl border accent-border text-center bg-black/[0.03]">
                        <p class="font-display text-xl accent-text font-semibold mb-1">JazakAllah Khair / Thank You!</p>
                        <p class="text-sm opacity-85">Your response and heartfelt blessings have been recorded.</p>
                    </div>
                </section>

                <!-- Footer Contact Info -->
                <?php if (!empty($config['contacts'])): ?>
                    <footer class="mt-12 pt-8 border-t accent-border text-center reveal-block">
                        <p class="text-[11px] uppercase tracking-[0.26em] opacity-70 mb-4">For Protocol, Assistance &amp; Directions</p>
                        <div class="flex flex-wrap justify-center gap-3">
                            <?php foreach ($config['contacts'] as $contact): ?>
                                <?php $cleanPhone = preg_replace('/[^0-9+]/', '', $contact['phone']); ?>
                                <div class="px-4 py-2.5 rounded-xl border accent-border flex items-center gap-3 text-xs">
                                    <span class="font-semibold"><?= htmlspecialchars($contact['name']) ?>:</span>
                                    <a href="tel:<?= $cleanPhone ?>" class="accent-text font-semibold hover:underline"><?= htmlspecialchars($contact['phone']) ?></a>
                                    <a href="https://wa.me/<?= ltrim($cleanPhone, '+') ?>" target="_blank" rel="noopener noreferrer" class="px-2.5 py-0.5 rounded bg-emerald-600 text-white text-[10px] font-semibold">WhatsApp</a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </footer>
                <?php endif; ?>

            </div>
        </article>
    </main>

    <script>
        // 1. MOBILE-NATIVE HTML5 WEDDING AUDIO GENERATOR
        const weddingAudio = document.getElementById('wedding-audio');
        const customMusicUrl = <?= json_encode($config['music_url'] ?? '') ?>;

        function buildBuiltInWeddingChimeWav() {
            const sampleRate = 22050;
            const duration = 3.6;
            const numSamples = Math.floor(sampleRate * duration);
            const buffer = new ArrayBuffer(44 + numSamples * 2);
            const view = new DataView(buffer);

            function writeStr(offset, str) {
                for (let i = 0; i < str.length; i++) {
                    view.setUint8(offset + i, str.charCodeAt(i));
                }
            }

            writeStr(0, 'RIFF');
            view.setUint32(4, 36 + numSamples * 2, true);
            writeStr(8, 'WAVE');
            writeStr(12, 'fmt ');
            view.setUint32(16, 16, true);
            view.setUint16(20, 1, true);
            view.setUint16(22, 1, true);
            view.setUint32(24, sampleRate, true);
            view.setUint32(28, sampleRate * 2, true);
            view.setUint16(32, 2, true);
            view.setUint16(34, 16, true);
            writeStr(36, 'data');
            view.setUint32(40, numSamples * 2, true);

            const chordNotes = [
                { freq: 392.00, start: 0.00 },
                { freq: 493.88, start: 0.14 },
                { freq: 587.33, start: 0.28 },
                { freq: 739.99, start: 0.42 },
                { freq: 783.99, start: 0.56 },
                { freq: 987.77, start: 0.72 },
                { freq: 1174.66, start: 0.90 }
            ];

            for (let i = 0; i < numSamples; i++) {
                const t = i / sampleRate;
                let signal = 0;

                for (let n = 0; n < chordNotes.length; n++) {
                    const note = chordNotes[n];
                    if (t >= note.start) {
                        const dt = t - note.start;
                        const env = Math.min(1, dt * 35) * Math.exp(-dt * 1.45);
                        const fundamental = Math.sin(2 * Math.PI * note.freq * dt);
                        const overtone = 0.28 * Math.sin(2 * Math.PI * note.freq * 2 * dt) * Math.exp(-dt * 2.5);
                        signal += (fundamental + overtone) * env * 0.22;
                    }
                }

                const clamped = Math.max(-1, Math.min(1, signal));
                view.setInt16(44 + i * 2, clamped * 32767, true);
            }

            const blob = new Blob([buffer], { type: 'audio/wav' });
            return URL.createObjectURL(blob);
        }

        if (customMusicUrl && customMusicUrl.trim() !== '') {
            weddingAudio.src = customMusicUrl;
            weddingAudio.loop = true;
        } else {
            weddingAudio.src = buildBuiltInWeddingChimeWav();
            weddingAudio.loop = false;
        }

        function startWeddingSound() {
            try {
                weddingAudio.currentTime = 0;
                const playPromise = weddingAudio.play();
                if (playPromise !== undefined) {
                    playPromise.then(function() {
                        document.getElementById('icon-sound-on').classList.remove('hidden');
                        document.getElementById('icon-sound-off').classList.add('hidden');
                    }).catch(function() {});
                }
            } catch (e) {}
        }

        function toggleAudio() {
            if (!weddingAudio.paused) {
                weddingAudio.pause();
                document.getElementById('icon-sound-on').classList.add('hidden');
                document.getElementById('icon-sound-off').classList.remove('hidden');
            } else {
                startWeddingSound();
            }
        }

        weddingAudio.addEventListener('ended', function() {
            if (!weddingAudio.loop) {
                document.getElementById('icon-sound-on').classList.add('hidden');
                document.getElementById('icon-sound-off').classList.remove('hidden');
            }
        });

        // 2. TACTILE 3D PARALLAX & ROYAL UNSEALING CHOREOGRAPHY
        let envelopeOpened = false;
        const shellEl = document.getElementById('envelope-shell');

        shellEl.addEventListener('pointermove', function(e) {
            if (envelopeOpened || e.pointerType !== 'mouse') return;
            const rect = shellEl.getBoundingClientRect();
            const nx = (e.clientX - rect.left) / rect.width - 0.5;
            const ny = (e.clientY - rect.top) / rect.height - 0.5;
            shellEl.style.transform = `rotateY(${nx * 6}deg) rotateX(${-ny * 6}deg)`;
        });

        shellEl.addEventListener('pointerleave', function() {
            if (!envelopeOpened) shellEl.style.transform = 'rotateY(0deg) rotateX(0deg)';
        });

        function burstGoldCelebration() {
            const cx = window.innerWidth / 2;
            const cy = window.innerHeight * 0.48;
            for (let i = 0; i < 50; i++) {
                const angle = Math.random() * Math.PI * 2;
                const speed = Math.random() * 6 + 1.5;
                particles.push({
                    type: i % 4 === 0 ? 'petal' : 'sparkle',
                    x: cx,
                    y: cy,
                    r: Math.random() * 3.5 + 1.5,
                    vx: Math.cos(angle) * speed,
                    vy: Math.sin(angle) * speed - 1.5,
                    rot: Math.random() * 360,
                    vrot: (Math.random() - 0.5) * 6,
                    alpha: 1,
                    decay: 0.011
                });
            }
        }

        function openEnvelope() {
            if (envelopeOpened) return;
            envelopeOpened = true;
            shellEl.style.transform = 'rotateY(0deg) rotateX(0deg)';

            startWeddingSound();

            const stage = document.getElementById('envelope-stage');
            const controls = document.getElementById('floating-controls');

            shellEl.classList.add('seal-broken');
            burstGoldCelebration();

            setTimeout(function() {
                shellEl.classList.add('is-opening');
            }, 300);

            setTimeout(function() {
                shellEl.classList.add('flap-behind');
            }, 950);

            setTimeout(function() {
                stage.classList.add('stage-fade-out');
                document.body.classList.remove('envelope-locked');
                controls.classList.remove('opacity-0', 'pointer-events-none');
                triggerScrollReveals();
            }, 1950);

            setTimeout(function() {
                stage.style.display = 'none';
            }, 2900);
        }

        function replayEnvelope() {
            const stage = document.getElementById('envelope-stage');
            const controls = document.getElementById('floating-controls');

            window.scrollTo({ top: 0, behavior: 'instant' });
            envelopeOpened = false;

            shellEl.classList.remove('seal-broken', 'is-opening', 'flap-behind');
            stage.style.display = 'flex';
            stage.classList.remove('stage-fade-out');
            document.body.classList.add('envelope-locked');
            controls.classList.add('opacity-0', 'pointer-events-none');
        }

        shellEl.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') openEnvelope();
        });

        // 3. SCROLL REVEAL OBSERVER
        function triggerScrollReveals() {
            const blocks = document.querySelectorAll('.reveal-block');
            const observer = new IntersectionObserver(function(entries) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                    }
                });
            }, { threshold: 0.12 });

            blocks.forEach(function(b) {
                observer.observe(b);
            });
        }

        // 4. LIVE COUNTDOWN TIMER
        const targetDate = new Date("<?= htmlspecialchars($config['wedding_date']) ?>").getTime();

        function updateCountdown() {
            const now = Date.now();
            const diff = Math.max(0, targetDate - now);

            const days = Math.floor(diff / (1000 * 60 * 60 * 24));
            const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
            const mins = Math.floor((diff / (1000 * 60)) % 60);
            const secs = Math.floor((diff / 1000) % 60);

            document.getElementById('cd-days').textContent = String(days).padStart(2, '0');
            document.getElementById('cd-hours').textContent = String(hours).padStart(2, '0');
            document.getElementById('cd-mins').textContent = String(mins).padStart(2, '0');
            document.getElementById('cd-secs').textContent = String(secs).padStart(2, '0');
        }
        updateCountdown();
        setInterval(updateCountdown, 1000);

        // 5. AJAX RSVP SUBMISSION
        document.getElementById('rsvp-form').addEventListener('submit', async function(e) {
            e.preventDefault();
            const btn = document.getElementById('rsvp-submit-btn');
            btn.disabled = true;
            btn.textContent = 'Recording Blessings...';

            const payload = {
                name: document.getElementById('rsvp-name').value,
                status: document.getElementById('rsvp-status').value,
                guests: document.getElementById('rsvp-guests').value,
                message: document.getElementById('rsvp-message').value,
                token: "<?= $verifiedToken ?>"
            };

            try {
                const res = await fetch('index.php?action=rsvp', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const data = await res.json();
                if (data.success) {
                    document.getElementById('rsvp-form').classList.add('hidden');
                    document.getElementById('rsvp-success').classList.remove('hidden');
                    burstGoldCelebration();
                } else {
                    alert(data.message || 'Could not submit RSVP.');
                    btn.disabled = false;
                    btn.textContent = 'Confirm RSVP & Send Blessings';
                }
            } catch (err) {
                alert('Network error. Please try again.');
                btn.disabled = false;
                btn.textContent = 'Confirm RSVP & Send Blessings';
            }
        });

        // 6. FLOATING ROSE PETALS & GOLDEN SPARKLE DUST CANVAS
        const canvas = document.getElementById('ambient-canvas');
        const ctx = canvas.getContext('2d');
        let particles = [];

        function resizeCanvas() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        }
        window.addEventListener('resize', resizeCanvas);
        resizeCanvas();

        for (let i = 0; i < 34; i++) {
            const isPetal = i % 3 === 0;
            particles.push({
                type: isPetal ? 'petal' : 'sparkle',
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                r: isPetal ? (Math.random() * 4.5 + 4) : (Math.random() * 2.2 + 0.8),
                vx: (Math.random() - 0.5) * 0.5,
                vy: isPetal ? (Math.random() * 0.65 + 0.35) : (-Math.random() * 0.4 - 0.15),
                rot: Math.random() * 360,
                vrot: (Math.random() - 0.5) * 1.8,
                alpha: Math.random() * 0.5 + 0.22,
                decay: 0
            });
        }

        function animateParticles() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            for (let i = particles.length - 1; i >= 0; i--) {
                const p = particles[i];
                p.x += p.vx;
                p.y += p.vy;
                p.rot += p.vrot;

                if (p.decay > 0) {
                    p.alpha -= p.decay;
                    p.vy += 0.08;
                    if (p.alpha <= 0) {
                        particles.splice(i, 1);
                        continue;
                    }
                } else {
                    if (p.y > canvas.height + 15) p.y = -15;
                    if (p.y < -15) p.y = canvas.height + 15;
                    if (p.x < -15) p.x = canvas.width + 15;
                    if (p.x > canvas.width + 15) p.x = -15;
                }

                ctx.save();
                ctx.translate(p.x, p.y);
                ctx.rotate((p.rot * Math.PI) / 180);

                if (p.type === 'petal') {
                    ctx.beginPath();
                    ctx.moveTo(0, -p.r);
                    ctx.bezierCurveTo(p.r, -p.r, p.r, p.r, 0, p.r);
                    ctx.bezierCurveTo(-p.r, p.r, -p.r, -p.r, 0, -p.r);
                    ctx.fillStyle = 'rgba(182, 53, 42, ' + p.alpha + ')';
                    ctx.fill();
                } else {
                    ctx.beginPath();
                    ctx.arc(0, 0, p.r, 0, Math.PI * 2);
                    ctx.fillStyle = 'rgba(218, 175, 62, ' + p.alpha + ')';
                    ctx.fill();
                }
                ctx.restore();
            }

            requestAnimationFrame(animateParticles);
        }
        animateParticles();
    </script>
</body>
</html>
<?php
// ==========================================
// PASSWORD-PROTECTED ADMIN PANEL (admin.php)
// Dual Design Templates (English Royal Mughal + Bengali Rajokio Modern)
// Preserves all existing config.json, guests.json, and rsvps.json data
// ==========================================

// >>> CHANGE THIS PASSWORD BEFORE UPLOADING <<<
$ADMIN_PASSWORD = 'admin1234';

$configFile = __DIR__ . '/config.json';
$guestsFile = __DIR__ . '/guests.json';
$rsvpsFile  = __DIR__ . '/rsvps.json';

$cookieName  = 'wedding_admin_auth_v2';
$expectedSig = hash_hmac('sha256', 'wedding_studio_unlocked', $ADMIN_PASSWORD);

// Logout Handler
if (isset($_GET['logout'])) {
    setcookie($cookieName, '', time() - 3600, '/');
    header('Location: ' . basename(__FILE__));
    exit;
}

// Login Handler
$loginError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_password'])) {
    if (hash_equals($ADMIN_PASSWORD, (string)$_POST['login_password'])) {
        setcookie($cookieName, $expectedSig, time() + (86400 * 7), '/');
        header('Location: ' . basename(__FILE__));
        exit;
    } else {
        $loginError = 'Incorrect password. Please try again.';
    }
}

$isAuthenticated = isset($_COOKIE[$cookieName]) && hash_equals($expectedSig, (string)$_COOKIE[$cookieName]);

if (!$isAuthenticated):
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login — Wedding Invitation Studio</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600&family=Plus+Jakarta+Sans:wght@400;500;600&display=swap" rel="stylesheet">
</head>
<body class="min-h-screen bg-[#181C14] text-stone-100 flex items-center justify-center p-4 font-['Plus_Jakarta_Sans']">
    <div class="w-full max-w-sm bg-[#22271D] border border-amber-500/25 rounded-2xl p-8 shadow-2xl">
        <div class="text-center mb-6">
            <p class="text-[11px] uppercase tracking-[0.25em] text-amber-400 mb-1">Private Access</p>
            <h1 class="font-['Cinzel'] text-2xl font-semibold text-white">Invitation Manager</h1>
        </div>
        <?php if ($loginError): ?>
            <div class="mb-4 p-3 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs text-center">
                <?= htmlspecialchars($loginError) ?>
            </div>
        <?php endif; ?>
        <form method="POST" class="space-y-4">
            <div>
                <label class="block text-xs uppercase tracking-wider text-stone-400 mb-1.5">Admin Password</label>
                <input type="password" name="login_password" required autofocus placeholder="Enter password" class="w-full px-4 py-3 rounded-xl bg-black/30 border border-white/15 text-white focus:outline-none focus:border-amber-400 text-sm">
            </div>
            <button type="submit" class="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-semibold text-sm transition cursor-pointer">
                Unlock Dashboard
            </button>
        </form>
    </div>
</body>
</html>
<?php
exit;
endif;

$defaultConfig = [
    'bismillah_arabic'  => 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ',
    'bismillah_text'    => 'In the name of Allah, the Most Gracious, the Most Merciful',
    'monogram'          => 'A & R',
    'bride_name'        => 'Ayesha Siddiqua',
    'groom_name'        => 'Rahim Uddin',
    'tagline'           => 'Two souls, one beautiful journey — begun with blessings',
    'parents_text'      => 'With the heartfelt blessings of Mr. & Mrs. Mojibul Haque',
    'invite_message'    => 'We joyfully request the honor of your presence and prayers as we unite in marriage and celebrate the beginning of our new life together.',
    'wedding_date'      => '2027-02-12T17:00:00',
    'date_display'      => 'FRIDAY, 12 FEBRUARY 2027 • 5:00 PM',
    // Optional dedicated Bengali overrides (falls back to main fields if left empty)
    'bn_monogram'       => 'শুভ বিবাহ',
    'bn_bismillah_text' => 'পরম করুণাময় ও অসীম দয়ালু আল্লাহর নামে শুরু করছি',
    'bn_bride_name'     => '',
    'bn_groom_name'     => '',
    'bn_tagline'        => 'দুটি প্রাণের পবিত্র মিলন — ভালোবাসা ও দোয়ায় নতুন পথচলা',
    'bn_parents_text'   => '',
    'bn_invite_message' => '',
    'bn_date_display'   => '',
    'music_url'         => '',
    'theme'             => 'olive_gold',
    'font_preset'       => 'royal_editorial',
    'template_lang'     => 'en',
    'custom_colors'     => ['envelope' => '#F2E6CE', 'bg' => '#1D1812', 'surface' => '#FCF8F0', 'accent' => '#B88928', 'text' => '#2A2115'],
    'events'            => [],
    'public_events'     => null,
    'contacts'          => []
];

if (!file_exists($configFile)) {
    @file_put_contents($configFile, json_encode($defaultConfig, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
}
$loadedConfig = file_exists($configFile) ? json_decode(@file_get_contents($configFile), true) : null;
$config = is_array($loadedConfig) ? array_merge($defaultConfig, $loadedConfig) : $defaultConfig;

// Ensure every event has a stable unique ID
if (!empty($config['events']) && is_array($config['events'])) {
    foreach ($config['events'] as $i => &$ev) {
        if (empty($ev['id'])) {
            $ev['id'] = 'ev_' . substr(md5(($ev['title'] ?? 'event') . '_' . $i), 0, 8);
        }
    }
    unset($ev);
}

$guests = file_exists($guestsFile) ? (json_decode(@file_get_contents($guestsFile), true) ?: []) : [];
$rsvps  = file_exists($rsvpsFile) ? (json_decode(@file_get_contents($rsvpsFile), true) ?: []) : [];

$toastMessage = '';
$errorAlert   = '';
$activeTab    = $_GET['tab'] ?? 'details';

if (!is_writable(__DIR__)) {
    $errorAlert = 'Warning: Folder is not writable. Please set folder permission to 0755 in cPanel.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['form_action'] ?? '';

    if ($action === 'save_details') {
        $config['bismillah_arabic']  = trim($_POST['bismillah_arabic'] ?? '');
        $config['bismillah_text']    = trim($_POST['bismillah_text'] ?? '');
        $config['monogram']          = trim($_POST['monogram'] ?? 'A & R');
        $config['bride_name']        = trim($_POST['bride_name'] ?? '');
        $config['groom_name']        = trim($_POST['groom_name'] ?? '');
        $config['tagline']           = trim($_POST['tagline'] ?? '');
        $config['parents_text']      = trim($_POST['parents_text'] ?? '');
        $config['invite_message']    = trim($_POST['invite_message'] ?? '');
        $config['wedding_date']      = trim($_POST['wedding_date'] ?? '');
        $config['date_display']      = trim($_POST['date_display'] ?? '');
        $config['music_url']         = trim($_POST['music_url'] ?? '');

        // Optional Bengali text overrides
        $config['bn_monogram']       = trim($_POST['bn_monogram'] ?? '');
        $config['bn_bismillah_text'] = trim($_POST['bn_bismillah_text'] ?? '');
        $config['bn_bride_name']     = trim($_POST['bn_bride_name'] ?? '');
        $config['bn_groom_name']     = trim($_POST['bn_groom_name'] ?? '');
        $config['bn_tagline']        = trim($_POST['bn_tagline'] ?? '');
        $config['bn_parents_text']   = trim($_POST['bn_parents_text'] ?? '');
        $config['bn_invite_message'] = trim($_POST['bn_invite_message'] ?? '');
        $config['bn_date_display']   = trim($_POST['bn_date_display'] ?? '');

        $events = [];
        if (!empty($_POST['event_title']) && is_array($_POST['event_title'])) {
            foreach ($_POST['event_title'] as $idx => $title) {
                if (trim($title) === '') continue;
                $evId = trim($_POST['event_id'][$idx] ?? '');
                if ($evId === '') {
                    $evId = 'ev_' . substr(md5(uniqid((string)mt_rand(), true)), 0, 8);
                }
                $events[] = [
                    'id'            => $evId,
                    'title'         => trim($title),
                    'date'          => trim($_POST['event_date'][$idx] ?? ''),
                    'time'          => trim($_POST['event_time'][$idx] ?? ''),
                    'venue'         => trim($_POST['event_venue'][$idx] ?? ''),
                    'dress_code'    => trim($_POST['event_dress'][$idx] ?? ''),
                    'map_url'       => trim($_POST['event_map'][$idx] ?? ''),
                    'bn_title'      => trim($_POST['event_bn_title'][$idx] ?? ''),
                    'bn_date'       => trim($_POST['event_bn_date'][$idx] ?? ''),
                    'bn_time'       => trim($_POST['event_bn_time'][$idx] ?? ''),
                    'bn_venue'      => trim($_POST['event_bn_venue'][$idx] ?? ''),
                    'bn_dress_code' => trim($_POST['event_bn_dress'][$idx] ?? '')
                ];
            }
        }
        $config['events'] = $events;

        $contacts = [];
        if (!empty($_POST['contact_name']) && is_array($_POST['contact_name'])) {
            foreach ($_POST['contact_name'] as $idx => $cname) {
                if (trim($cname) === '' || trim($_POST['contact_phone'][$idx] ?? '') === '') continue;
                $contacts[] = [
                    'name'    => trim($cname),
                    'bn_name' => trim($_POST['contact_bn_name'][$idx] ?? ''),
                    'phone'   => trim($_POST['contact_phone'][$idx])
                ];
            }
        }
        $config['contacts'] = $contacts;

        if (@file_put_contents($configFile, json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX) !== false) {
            $toastMessage = 'All wedding & bilingual template details saved safely!';
        } else {
            $errorAlert = 'Could not save config.json. Check folder permissions (0755).';
        }
        $activeTab = 'details';
    }

    if ($action === 'save_design') {
        $config['template_lang'] = in_array($_POST['template_lang'] ?? 'en', ['en', 'bn'], true) ? $_POST['template_lang'] : 'en';
        $config['theme']         = $_POST['theme'] ?? 'olive_gold';
        $config['font_preset']   = $_POST['font_preset'] ?? 'royal_editorial';
        $config['custom_colors'] = [
            'envelope' => $_POST['custom_envelope'] ?? '#F2E6CE',
            'bg'       => $_POST['custom_bg'] ?? '#1D1812',
            'surface'  => $_POST['custom_surface'] ?? '#FCF8F0',
            'accent'   => $_POST['custom_accent'] ?? '#B88928',
            'text'     => $_POST['custom_text'] ?? '#2A2115'
        ];
        @file_put_contents($configFile, json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
        $toastMessage = 'Default template design, theme, and typography updated!';
        $activeTab = 'design';
    }

    if ($action === 'add_guests') {
        $rawLines = explode("\n", $_POST['guest_names'] ?? '');
        $selectedEvents = isset($_POST['allowed_events']) && is_array($_POST['allowed_events'])
            ? array_values(array_map('strval', $_POST['allowed_events']))
            : [];
        $guestLang = in_array($_POST['guest_lang'] ?? 'default', ['default', 'en', 'bn'], true) ? $_POST['guest_lang'] : 'default';
        $guestCustomNote = trim($_POST['guest_custom_note'] ?? '');
        $addedCount = 0;

        foreach ($rawLines as $line) {
            $name = trim($line);
            if ($name === '') continue;

            $slug = strtolower(preg_replace('/[^a-zA-Z0-9]+/', '-', $name));
            $slug = trim($slug, '-');
            if ($slug === '') $slug = 'guest';
            $slug = substr($slug, 0, 18);

            $randomCode = substr(md5(uniqid((string)mt_rand(), true)), 0, 4);
            $token = $slug . '-' . $randomCode;

            array_unshift($guests, [
                'token'          => $token,
                'name'           => $name,
                'lang'           => $guestLang,
                'custom_note'    => $guestCustomNote,
                'allowed_events' => $selectedEvents,
                'views'          => 0,
                'last_viewed'    => null
            ]);
            $addedCount++;
        }

        if ($addedCount > 0) {
            @file_put_contents($guestsFile, json_encode($guests, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
            $toastMessage = "{$addedCount} customized guest invitation link(s) generated!";
        }
        $activeTab = 'guests';
    }

    if ($action === 'update_guest_events') {
        $targetToken = $_POST['token'] ?? '';
        $updatedEvents = isset($_POST['guest_events']) && is_array($_POST['guest_events'])
            ? array_values(array_map('strval', $_POST['guest_events']))
            : [];
        $updatedLang = in_array($_POST['guest_lang'] ?? 'default', ['default', 'en', 'bn'], true) ? $_POST['guest_lang'] : 'default';
        $updatedName = trim($_POST['guest_name_edit'] ?? '');
        $updatedNote = trim($_POST['guest_custom_note'] ?? '');

        foreach ($guests as &$g) {
            if (($g['token'] ?? '') === $targetToken) {
                if ($updatedName !== '') {
                    $g['name'] = $updatedName;
                }
                $g['allowed_events'] = $updatedEvents;
                $g['lang']           = $updatedLang;
                $g['custom_note']    = $updatedNote;
                break;
            }
        }
        unset($g);

        @file_put_contents($guestsFile, json_encode($guests, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
        $toastMessage = 'Guest template design, events & custom settings updated!';
        $activeTab = 'guests';
    }

    if ($action === 'save_public_events') {
        $pubEvents = isset($_POST['public_events']) && is_array($_POST['public_events'])
            ? array_values(array_map('strval', $_POST['public_events']))
            : [];
        $config['public_events'] = $pubEvents;
        @file_put_contents($configFile, json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
        $toastMessage = 'Public link event visibility saved!';
        $activeTab = 'guests';
    }

    if ($action === 'delete_guest') {
        $delToken = $_POST['token'] ?? '';
        $newGuests = [];
        foreach ($guests as $g) {
            if (($g['token'] ?? '') !== $delToken) {
                $newGuests[] = $g;
            }
        }
        $guests = $newGuests;
        @file_put_contents($guestsFile, json_encode($guests, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
        $toastMessage = 'Guest link revoked and removed.';
        $activeTab = 'guests';
    }

    if ($action === 'delete_rsvp') {
        $delId = $_POST['rsvp_id'] ?? '';
        $newRsvps = [];
        foreach ($rsvps as $r) {
            if (($r['id'] ?? '') !== $delId) {
                $newRsvps[] = $r;
            }
        }
        $rsvps = $newRsvps;
        @file_put_contents($rsvpsFile, json_encode($rsvps, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
        $toastMessage = 'RSVP entry removed.';
        $activeTab = 'rsvps';
    }
}

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$dirPath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$baseUrl = $scheme . '://' . $_SERVER['HTTP_HOST'] . $dirPath . '/';

$eventTitleMap = [];
foreach (($config['events'] ?? []) as $ev) {
    $eventTitleMap[$ev['id']] = $ev['title'];
}

$themeCatalog = [
    'olive_gold'          => ['label' => 'Royal Ivory & Gold (Default)', 'colors' => ['#F3E7CE', '#FCF8F0', '#B88928']],
    'emerald_gold'        => ['label' => 'Royal Emerald & Gold', 'colors' => ['#073B2C', '#083E2F', '#D4AF37']],
    'maroon_cream'        => ['label' => 'Classic Maroon & Cream (Bengali Royal)', 'colors' => ['#59111B', '#FCF6EC', '#B8862D']],
    'dusty_rose'          => ['label' => 'Dusty Rose & Champagne', 'colors' => ['#965163', '#FEF7F7', '#B87684']],
    'midnight_navy'       => ['label' => 'Midnight Navy & Silver', 'colors' => ['#0F223D', '#0D1E36', '#D6C08D']],
    'ivory_terracotta'    => ['label' => 'Ivory Pearl & Terracotta', 'colors' => ['#A85234', '#FCF8F2', '#B55B3C']],
    'sage_brass'          => ['label' => 'Sage Olive & Antique Brass', 'colors' => ['#374A3A', '#F7F8F3', '#B68F40']],
    'obsidian_rosegold'   => ['label' => 'Obsidian Charcoal & Rose Gold', 'colors' => ['#1A181B', '#171518', '#E2A796']],
    'aubergine_champagne' => ['label' => 'Royal Aubergine & Champagne', 'colors' => ['#3B143A', '#30102F', '#E5C382']],
    'peacock_saffron'     => ['label' => 'Peacock Teal & Saffron Gold', 'colors' => ['#094E5E', '#F8FAFA', '#D18F19']],
    'custom'              => ['label' => 'Custom Color Palette', 'colors' => ['#444444', '#FFFFFF', '#D4AF37']]
];

$attendingGuests = 0;
$declinedCount   = 0;
foreach ($rsvps as $r) {
    if (($r['status'] ?? '') === 'Joyfully Attending') {
        $attendingGuests += (int)($r['guests'] ?? 1);
    } else {
        $declinedCount++;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wedding Card Admin Dashboard — Dual Design Studio</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600&family=Noto+Serif+Bengali:wght@500;600&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="min-h-screen bg-[#141712] text-stone-100 font-['Plus_Jakarta_Sans']">

    <header class="bg-[#1C2019] border-b border-white/10 sticky top-0 z-30">
        <div class="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-4">
            <div>
                <h1 class="font-['Cinzel'] text-xl sm:text-2xl font-semibold text-amber-400">Wedding Card Studio</h1>
                <p class="text-xs text-stone-400">Design 1: English Royal Mughal • Design 2: বাংলা রাজকীয় আধুনিক নিমন্ত্রণপত্র</p>
            </div>
            <div class="flex flex-wrap items-center gap-2.5">
                <a href="<?= htmlspecialchars($baseUrl) ?>?lang=en" target="_blank" class="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold transition">
                    Design 1: English ↗
                </a>
                <a href="<?= htmlspecialchars($baseUrl) ?>?lang=bn" target="_blank" class="px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 text-xs font-['Noto_Serif_Bengali'] font-semibold transition">
                    Design 2: বাংলা রাজকীয় ↗
                </a>
                <a href="?logout=1" class="px-3.5 py-2 rounded-xl bg-red-500/15 hover:bg-red-500/25 text-red-300 border border-red-500/25 text-xs font-semibold transition">
                    Logout
                </a>
            </div>
        </div>
    </header>

    <main class="max-w-6xl mx-auto px-4 sm:px-6 py-8">

        <?php if ($errorAlert): ?>
            <div class="mb-6 p-4 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-sm">
                <?= htmlspecialchars($errorAlert) ?>
            </div>
        <?php endif; ?>

        <?php if ($toastMessage): ?>
            <div class="mb-6 p-4 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-sm flex items-center justify-between">
                <span><?= htmlspecialchars($toastMessage) ?></span>
                <button onclick="this.parentElement.remove()" class="text-emerald-300/70 hover:text-white">✕</button>
            </div>
        <?php endif; ?>

        <div class="flex flex-wrap gap-2 mb-8 border-b border-white/10 pb-4">
            <a href="?tab=details" class="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition <?= $activeTab === 'details' ? 'bg-amber-500 text-stone-950' : 'bg-white/5 text-stone-300 hover:bg-white/10' ?>">
                1. Wedding &amp; Bilingual Content
            </a>
            <a href="?tab=design" class="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition <?= $activeTab === 'design' ? 'bg-amber-500 text-stone-950' : 'bg-white/5 text-stone-300 hover:bg-white/10' ?>">
                2. Template Design &amp; Theme
            </a>
            <a href="?tab=guests" class="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition <?= $activeTab === 'guests' ? 'bg-amber-500 text-stone-950' : 'bg-white/5 text-stone-300 hover:bg-white/10' ?>">
                3. Send / Customize Guest Cards (<?= count($guests) ?>)
            </a>
            <a href="?tab=rsvps" class="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition <?= $activeTab === 'rsvps' ? 'bg-amber-500 text-stone-950' : 'bg-white/5 text-stone-300 hover:bg-white/10' ?>">
                4. RSVPs &amp; Wishes (<?= count($rsvps) ?>)
            </a>
        </div>

        <?php if ($activeTab === 'details'): ?>
            <form method="POST" class="space-y-8">
                <input type="hidden" name="form_action" value="save_details">

                <!-- Primary / English Template Content (Unchanged & Preserved) -->
                <div class="bg-[#1C2019] border border-white/10 rounded-2xl p-6 space-y-5">
                    <div>
                        <h2 class="text-lg font-semibold text-amber-400">Primary / Design 1 (English Royal Mughal) Details</h2>
                        <p class="text-xs text-stone-400">Your existing card data is preserved here. Design 2 (Bangla) will also use these if separate Bengali text below is left blank.</p>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">Envelope Gold Monogram</label>
                            <input type="text" name="monogram" value="<?= htmlspecialchars($config['monogram'] ?? 'A & R') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                        </div>
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">Bride's Name</label>
                            <input type="text" name="bride_name" required value="<?= htmlspecialchars($config['bride_name'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                        </div>
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">Groom's Name</label>
                            <input type="text" name="groom_name" required value="<?= htmlspecialchars($config['groom_name'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">Arabic Header (Optional)</label>
                            <input type="text" name="bismillah_arabic" value="<?= htmlspecialchars($config['bismillah_arabic'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                        </div>
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">Sub-header Line</label>
                            <input type="text" name="bismillah_text" value="<?= htmlspecialchars($config['bismillah_text'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">Tagline</label>
                            <input type="text" name="tagline" value="<?= htmlspecialchars($config['tagline'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                        </div>
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">Default Display Date Text</label>
                            <input type="text" name="date_display" value="<?= htmlspecialchars($config['date_display'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                        </div>
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">Countdown Target (YYYY-MM-DDTHH:MM:SS)</label>
                            <input type="text" name="wedding_date" value="<?= htmlspecialchars($config['wedding_date'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs text-stone-400 mb-1">Custom Background Music MP3 URL (Leave empty for built-in Soft Wedding Piano)</label>
                        <input type="url" name="music_url" value="<?= htmlspecialchars($config['music_url'] ?? '') ?>" placeholder="https://example.com/music.mp3 (Optional)" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                    </div>

                    <div>
                        <label class="block text-xs text-stone-400 mb-1">Parents' / Host Line</label>
                        <input type="text" name="parents_text" value="<?= htmlspecialchars($config['parents_text'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm">
                    </div>

                    <div>
                        <label class="block text-xs text-stone-400 mb-1">Main Invitation Message</label>
                        <textarea name="invite_message" rows="3" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm"><?= htmlspecialchars($config['invite_message'] ?? '') ?></textarea>
                    </div>
                </div>

                <!-- Optional Dedicated Bengali Text for Design 2 (So English & Bangla can both stay active simultaneously!) -->
                <div class="bg-[#1C2019] border border-amber-500/30 rounded-2xl p-6 space-y-5">
                    <div class="flex flex-wrap items-center justify-between gap-3">
                        <div>
                            <h2 class="font-['Noto_Serif_Bengali'] text-lg font-semibold text-amber-400">Design 2: বাংলা রাজকীয় নিমন্ত্রণপত্রের আলাদা টেক্সট (ঐচ্ছিক)</h2>
                            <p class="text-xs text-stone-400">এখানে বাংলায় লিখলে Design 1 (English) অপরিবর্তিত থাকবে এবং Design 2 (বাংলা) কার্ডে এই বাংলা লেখাগুলো দেখাবে।</p>
                        </div>
                        <button type="button" onclick="fillBanglaSampleTexts()" class="px-3.5 py-2 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 text-xs font-['Noto_Serif_Bengali'] font-semibold transition cursor-pointer">
                            বাংলা নমুনা ফরম্যাট বসান
                        </button>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">বাংলা সীলমোহর লেখা (Monogram)</label>
                            <input type="text" id="bn_monogram" name="bn_monogram" value="<?= htmlspecialchars($config['bn_monogram'] ?? 'শুভ বিবাহ') ?>" placeholder="শুভ বিবাহ" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm font-['Noto_Serif_Bengali']">
                        </div>
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">কনের নাম (বাংলায়)</label>
                            <input type="text" id="bn_bride_name" name="bn_bride_name" value="<?= htmlspecialchars($config['bn_bride_name'] ?? '') ?>" placeholder="যেমন: আয়েশা সিদ্দিকা" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm font-['Noto_Serif_Bengali']">
                        </div>
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">বরের নাম (বাংলায়)</label>
                            <input type="text" id="bn_groom_name" name="bn_groom_name" value="<?= htmlspecialchars($config['bn_groom_name'] ?? '') ?>" placeholder="যেমন: রহিম উদ্দিন" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm font-['Noto_Serif_Bengali']">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">শুরুতে দোয়া / উপশিরোনাম (বাংলায়)</label>
                            <input type="text" id="bn_bismillah_text" name="bn_bismillah_text" value="<?= htmlspecialchars($config['bn_bismillah_text'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm font-['Noto_Serif_Bengali']">
                        </div>
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">ট্যাগলাইন (বাংলায়)</label>
                            <input type="text" id="bn_tagline" name="bn_tagline" value="<?= htmlspecialchars($config['bn_tagline'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm font-['Noto_Serif_Bengali']">
                        </div>
                        <div>
                            <label class="block text-xs text-stone-400 mb-1">তারিখ ও সময় (বাংলায়)</label>
                            <input type="text" id="bn_date_display" name="bn_date_display" value="<?= htmlspecialchars($config['bn_date_display'] ?? '') ?>" placeholder="শুক্রবার, ১২ ফেব্রুয়ারি ২০২৭ • বিকাল ৫:০০ ঘটিকা" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm font-['Noto_Serif_Bengali']">
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs text-stone-400 mb-1">অভিভাবক / দাওয়াতদাতা লাইন (বাংলায়)</label>
                        <input type="text" id="bn_parents_text" name="bn_parents_text" value="<?= htmlspecialchars($config['bn_parents_text'] ?? '') ?>" placeholder="জনাব মজিবুল হক ও মিসেস মজিবুল হক-এর স্নেহধন্য কন্যার শুভ বিবাহ উপলক্ষে" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm font-['Noto_Serif_Bengali']">
                    </div>

                    <div>
                        <label class="block text-xs text-stone-400 mb-1">মূল আমন্ত্রণ বার্তা (বাংলায়)</label>
                        <textarea id="bn_invite_message" name="bn_invite_message" rows="2" placeholder="আমাদের প্রিয় কন্যার শুভ বিবাহের এই আনন্দঘন মুহূর্তে আপনার ও আপনার পরিবারের সাদর উপস্থিতি এবং আন্তরিক দোয়া আমাদের একান্ত কাম্য।" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-sm font-['Noto_Serif_Bengali']"><?= htmlspecialchars($config['bn_invite_message'] ?? '') ?></textarea>
                    </div>
                </div>

                <!-- Event Schedule (with optional Bangla fields per event) -->
                <div class="bg-[#1C2019] border border-white/10 rounded-2xl p-6 space-y-5">
                    <div class="flex items-center justify-between">
                        <div>
                            <h2 class="text-lg font-semibold text-amber-400">Event Schedule (English &amp; Optional Bangla)</h2>
                            <p class="text-xs text-stone-400">Each event supports English details plus optional Bangla equivalents for Design 2.</p>
                        </div>
                        <button type="button" onclick="addEventRow()" class="px-3.5 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-semibold hover:bg-amber-500/30">
                            + Add Event
                        </button>
                    </div>

                    <div id="events-container" class="space-y-4">
                        <?php foreach (($config['events'] ?? []) as $ev): ?>
                            <div class="p-4 rounded-xl bg-black/25 border border-white/10 space-y-3 relative event-row">
                                <input type="hidden" name="event_id[]" value="<?= htmlspecialchars($ev['id']) ?>">
                                <button type="button" onclick="this.parentElement.remove()" class="absolute top-3 right-3 text-xs text-red-400 hover:underline">Remove</button>
                                <p class="text-[11px] uppercase tracking-wider text-stone-400 font-semibold">English Details (Design 1)</p>
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                                    <input type="text" name="event_title[]" value="<?= htmlspecialchars($ev['title']) ?>" placeholder="Event Title (EN)" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                                    <input type="text" name="event_date[]" value="<?= htmlspecialchars($ev['date']) ?>" placeholder="Date (EN)" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                                    <input type="text" name="event_time[]" value="<?= htmlspecialchars($ev['time']) ?>" placeholder="Time (EN)" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                                </div>
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                                    <input type="text" name="event_venue[]" value="<?= htmlspecialchars($ev['venue']) ?>" placeholder="Venue Address (EN)" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                                    <input type="text" name="event_dress[]" value="<?= htmlspecialchars($ev['dress_code'] ?? '') ?>" placeholder="Dress Code (EN)" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                                    <input type="url" name="event_map[]" value="<?= htmlspecialchars($ev['map_url'] ?? '') ?>" placeholder="Google Maps URL" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                                </div>

                                <p class="text-[11px] text-amber-300/80 font-['Noto_Serif_Bengali'] pt-1">বাংলা অনুবাদ (Design 2 — ঐচ্ছিক)</p>
                                <div class="grid grid-cols-1 md:grid-cols-5 gap-2.5">
                                    <input type="text" name="event_bn_title[]" value="<?= htmlspecialchars($ev['bn_title'] ?? '') ?>" placeholder="অনুষ্ঠানের নাম (বাংলা)" class="px-3 py-2 rounded-lg bg-black/30 border border-amber-500/20 text-xs font-['Noto_Serif_Bengali']">
                                    <input type="text" name="event_bn_date[]" value="<?= htmlspecialchars($ev['bn_date'] ?? '') ?>" placeholder="তারিখ (বাংলা)" class="px-3 py-2 rounded-lg bg-black/30 border border-amber-500/20 text-xs font-['Noto_Serif_Bengali']">
                                    <input type="text" name="event_bn_time[]" value="<?= htmlspecialchars($ev['bn_time'] ?? '') ?>" placeholder="সময় (বাংলা)" class="px-3 py-2 rounded-lg bg-black/30 border border-amber-500/20 text-xs font-['Noto_Serif_Bengali']">
                                    <input type="text" name="event_bn_venue[]" value="<?= htmlspecialchars($ev['bn_venue'] ?? '') ?>" placeholder="স্থান / ভেন্যু (বাংলা)" class="px-3 py-2 rounded-lg bg-black/30 border border-amber-500/20 text-xs font-['Noto_Serif_Bengali']">
                                    <input type="text" name="event_bn_dress[]" value="<?= htmlspecialchars($ev['bn_dress_code'] ?? '') ?>" placeholder="পোশাক (বাংলা)" class="px-3 py-2 rounded-lg bg-black/30 border border-amber-500/20 text-xs font-['Noto_Serif_Bengali']">
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="bg-[#1C2019] border border-white/10 rounded-2xl p-6 space-y-4">
                    <div class="flex items-center justify-between">
                        <h2 class="text-lg font-semibold text-amber-400">Host Contacts (Call &amp; WhatsApp)</h2>
                        <button type="button" onclick="addContactRow()" class="px-3.5 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-semibold hover:bg-amber-500/30">
                            + Add Contact
                        </button>
                    </div>
                    <div id="contacts-container" class="space-y-3">
                        <?php foreach (($config['contacts'] ?? []) as $ct): ?>
                            <div class="grid grid-cols-1 sm:grid-cols-4 gap-3 items-center">
                                <input type="text" name="contact_name[]" value="<?= htmlspecialchars($ct['name']) ?>" placeholder="Name / Relation (EN)" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                                <input type="text" name="contact_bn_name[]" value="<?= htmlspecialchars($ct['bn_name'] ?? '') ?>" placeholder="নাম / পরিচয় (বাংলা - ঐচ্ছিক)" class="px-3 py-2 rounded-lg bg-black/30 border border-amber-500/20 text-sm font-['Noto_Serif_Bengali']">
                                <input type="text" name="contact_phone[]" value="<?= htmlspecialchars($ct['phone']) ?>" placeholder="+8801XXXXXXXXX" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                                <button type="button" onclick="this.parentElement.remove()" class="text-xs text-red-400 hover:underline text-left sm:text-center">Remove</button>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <button type="submit" class="px-8 py-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-sm shadow-lg cursor-pointer">
                    Save All Settings
                </button>
            </form>

        <?php elseif ($activeTab === 'design'): ?>
            <form method="POST" class="space-y-8">
                <input type="hidden" name="form_action" value="save_design">

                <!-- 2 Distinct Template Designs Selector -->
                <div class="bg-[#1C2019] border border-amber-500/30 rounded-2xl p-6 space-y-4">
                    <div>
                        <h2 class="text-lg font-semibold text-amber-400">Select Default Card Template Design (২টি আলাদা ডিজাইন)</h2>
                        <p class="text-xs text-stone-400 mt-0.5">Choose the default design for public visitors. You can also assign either design individually to any guest when sending links in Tab 3.</p>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <label class="cursor-pointer block">
                            <input type="radio" name="template_lang" value="en" class="peer sr-only" <?= ($config['template_lang'] ?? 'en') === 'en' ? 'checked' : '' ?>>
                            <div class="p-5 rounded-2xl border-2 border-white/15 bg-black/30 peer-checked:border-amber-400 peer-checked:bg-amber-500/15 transition h-full">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="px-2.5 py-0.5 rounded-full bg-sky-500/20 text-sky-300 text-[10px] font-bold uppercase tracking-wider">Design 1 • Unchanged</span>
                                    <a href="<?= htmlspecialchars($baseUrl) ?>?lang=en" target="_blank" class="text-xs text-amber-300 hover:underline">Live Preview ↗</a>
                                </div>
                                <p class="font-['Cinzel'] text-lg font-semibold text-white">English Royal Mughal Ivory</p>
                                <p class="text-xs text-stone-300 mt-1.5 leading-relaxed">
                                    Hand-painted Mughal floral vine cotton-ivory envelope, melted gold wax seal, and Mughal canopy arch card layout.
                                </p>
                            </div>
                        </label>

                        <label class="cursor-pointer block">
                            <input type="radio" name="template_lang" value="bn" class="peer sr-only" <?= ($config['template_lang'] ?? 'en') === 'bn' ? 'checked' : '' ?>>
                            <div class="p-5 rounded-2xl border-2 border-white/15 bg-black/30 peer-checked:border-amber-400 peer-checked:bg-amber-500/15 transition h-full">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold tracking-wider">Design 2 • রাজকীয় ও মডার্ন</span>
                                    <a href="<?= htmlspecialchars($baseUrl) ?>?lang=bn" target="_blank" class="text-xs text-amber-300 hover:underline">বাংলা প্রিভিউ ↗</a>
                                </div>
                                <p class="font-['Noto_Serif_Bengali'] text-lg font-semibold text-amber-300">বাংলা রাজকীয় ঐতিহ্যবাহী নিমন্ত্রণপত্র (Modern Look)</p>
                                <p class="font-['Noto_Serif_Bengali'] text-xs text-stone-300 mt-1.5 leading-relaxed">
                                    জামদানি ও আলপনা কারুকাজখচিত রাজকীয় খাম, শুভ বিবাহ কল্কা সীলমোহর, শতদল পদ্ম ও কল্কা তোরণ এবং আধুনিক এডিটোরিয়াল কার্ড ডিজাইন।
                                </p>
                            </div>
                        </label>
                    </div>
                </div>

                <div class="bg-[#1C2019] border border-white/10 rounded-2xl p-6 space-y-5">
                    <h2 class="text-lg font-semibold text-amber-400">Select Luxury Color Theme</h2>
                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        <?php foreach ($themeCatalog as $key => $info): ?>
                            <label class="cursor-pointer block">
                                <input type="radio" name="theme" value="<?= $key ?>" class="peer sr-only" <?= ($config['theme'] ?? 'olive_gold') === $key ? 'checked' : '' ?>>
                                <div class="p-4 rounded-xl border border-white/15 bg-black/25 peer-checked:border-amber-400 peer-checked:bg-amber-500/10 transition">
                                    <div class="flex items-center gap-2 mb-2.5">
                                        <?php foreach ($info['colors'] as $hex): ?>
                                            <span class="w-6 h-6 rounded-full border border-white/25" style="background-color: <?= $hex ?>;"></span>
                                        <?php endforeach; ?>
                                    </div>
                                    <p class="text-sm font-medium text-stone-200"><?= htmlspecialchars($info['label']) ?></p>
                                </div>
                            </label>
                        <?php endforeach; ?>
                    </div>

                    <div class="pt-4 border-t border-white/10">
                        <p class="text-xs uppercase tracking-wider text-stone-400 mb-3">Custom Color Palette (Active when "Custom Color Palette" is selected)</p>
                        <?php $cc = $config['custom_colors'] ?? ['envelope' => '#F2E6CE', 'bg' => '#1D1812', 'surface' => '#FCF8F0', 'accent' => '#B88928', 'text' => '#2A2115']; ?>
                        <div class="grid grid-cols-2 sm:grid-cols-5 gap-4">
                            <div>
                                <label class="block text-xs text-stone-400 mb-1">Envelope Color</label>
                                <input type="color" name="custom_envelope" value="<?= htmlspecialchars($cc['envelope']) ?>" class="w-full h-10 rounded cursor-pointer bg-transparent">
                            </div>
                            <div>
                                <label class="block text-xs text-stone-400 mb-1">Outer Backdrop</label>
                                <input type="color" name="custom_bg" value="<?= htmlspecialchars($cc['bg']) ?>" class="w-full h-10 rounded cursor-pointer bg-transparent">
                            </div>
                            <div>
                                <label class="block text-xs text-stone-400 mb-1">Card Surface</label>
                                <input type="color" name="custom_surface" value="<?= htmlspecialchars($cc['surface']) ?>" class="w-full h-10 rounded cursor-pointer bg-transparent">
                            </div>
                            <div>
                                <label class="block text-xs text-stone-400 mb-1">Gold / Accent</label>
                                <input type="color" name="custom_accent" value="<?= htmlspecialchars($cc['accent']) ?>" class="w-full h-10 rounded cursor-pointer bg-transparent">
                            </div>
                            <div>
                                <label class="block text-xs text-stone-400 mb-1">Card Text</label>
                                <input type="color" name="custom_text" value="<?= htmlspecialchars($cc['text']) ?>" class="w-full h-10 rounded cursor-pointer bg-transparent">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bg-[#1C2019] border border-white/10 rounded-2xl p-6 space-y-4">
                    <h2 class="text-lg font-semibold text-amber-400">Typography Style (Design 1 — English Mode)</h2>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <label class="cursor-pointer block">
                            <input type="radio" name="font_preset" value="royal_editorial" class="peer sr-only" <?= ($config['font_preset'] ?? 'royal_editorial') === 'royal_editorial' ? 'checked' : '' ?>>
                            <div class="p-4 rounded-xl border border-white/15 bg-black/25 peer-checked:border-amber-400 peer-checked:bg-amber-500/10">
                                <p class="font-['Cinzel'] text-lg text-white mb-1">Royal Editorial Serif</p>
                                <p class="text-xs text-stone-400">Cinzel + Cormorant Garamond (Recommended)</p>
                            </div>
                        </label>
                        <label class="cursor-pointer block">
                            <input type="radio" name="font_preset" value="classic_aristocrat" class="peer sr-only" <?= ($config['font_preset'] ?? '') === 'classic_aristocrat' ? 'checked' : '' ?>>
                            <div class="p-4 rounded-xl border border-white/15 bg-black/25 peer-checked:border-amber-400 peer-checked:bg-amber-500/10">
                                <p class="font-serif text-lg text-white mb-1">Classic Aristocrat</p>
                                <p class="text-xs text-stone-400">Playfair Display + Lora</p>
                            </div>
                        </label>
                        <label class="cursor-pointer block">
                            <input type="radio" name="font_preset" value="modern_luxury" class="peer sr-only" <?= ($config['font_preset'] ?? '') === 'modern_luxury' ? 'checked' : '' ?>>
                            <div class="p-4 rounded-xl border border-white/15 bg-black/25 peer-checked:border-amber-400 peer-checked:bg-amber-500/10">
                                <p class="tracking-widest uppercase text-base font-semibold text-white mb-1">Modern Minimalist</p>
                                <p class="text-xs text-stone-400">Montserrat + Cormorant Garamond</p>
                            </div>
                        </label>
                    </div>
                </div>

                <button type="submit" class="px-8 py-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-sm shadow-lg cursor-pointer">
                    Apply Design &amp; Theme Settings
                </button>
            </form>

        <?php elseif ($activeTab === 'guests'): ?>
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div class="space-y-6">
                    <div class="bg-[#1C2019] border border-amber-500/30 rounded-2xl p-6">
                        <h2 class="text-lg font-semibold text-amber-400 mb-1.5">Create &amp; Send Customized Card</h2>
                        <p class="text-xs text-stone-400 mb-4 leading-relaxed">
                            Customize which template design, events, and personal greeting note to send to each guest.
                        </p>
                        <form method="POST" class="space-y-4">
                            <input type="hidden" name="form_action" value="add_guests">

                            <!-- Choose Template Design when sending -->
                            <div>
                                <label class="block text-xs text-amber-300 font-semibold mb-1.5">1. Choose Card Template Design</label>
                                <select name="guest_lang" class="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-amber-500/30 text-xs text-stone-100 focus:outline-none focus:border-amber-400">
                                    <option value="default">Default (Follow Global Setting)</option>
                                    <option value="bn">Design 2: বাংলা রাজকীয় নিমন্ত্রণপত্র (Bangla)</option>
                                    <option value="en">Design 1: English Royal Mughal</option>
                                </select>
                            </div>

                            <!-- Program Selection Checkboxes -->
                            <div class="p-3.5 rounded-xl bg-black/30 border border-white/15 space-y-2.5">
                                <div class="flex items-center justify-between">
                                    <span class="text-[11px] uppercase tracking-wider text-amber-300 font-semibold">2. Invited Programs:</span>
                                    <button type="button" onclick="toggleAllCreateEvents(true)" class="text-[11px] text-stone-400 hover:text-white underline">Select All</button>
                                </div>
                                <?php if (empty($config['events'])): ?>
                                    <p class="text-xs text-red-300">No events found. Add events in Tab 1 first.</p>
                                <?php else: ?>
                                    <?php foreach ($config['events'] as $ev): ?>
                                        <label class="flex items-center gap-2.5 text-xs text-stone-200 cursor-pointer hover:text-amber-300 transition">
                                            <input type="checkbox" name="allowed_events[]" value="<?= htmlspecialchars($ev['id']) ?>" checked class="create-event-cb w-4 h-4 rounded accent-amber-500 cursor-pointer">
                                            <span><?= htmlspecialchars($ev['title']) ?></span>
                                        </label>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>

                            <!-- Optional Personal Greeting Note -->
                            <div>
                                <label class="block text-xs text-stone-400 mb-1">3. Custom Greeting Note (Optional)</label>
                                <input type="text" name="guest_custom_note" placeholder="e.g. বিশেষভাবে আমন্ত্রিত / Looking forward to seeing you!" class="w-full px-3.5 py-2.5 rounded-xl bg-black/30 border border-white/15 text-xs focus:outline-none focus:border-amber-400">
                            </div>

                            <div>
                                <label class="block text-xs text-stone-400 mb-1.5">4. Guest Name(s) (One per line)</label>
                                <textarea name="guest_names" rows="4" required placeholder="Mitu Apa & Family&#10;মজিবুর রহমান চাচা ও পরিবার&#10;Dr. Tanvir Ahmed" class="w-full px-3.5 py-3 rounded-xl bg-black/30 border border-white/15 text-sm leading-relaxed focus:outline-none focus:border-amber-400"></textarea>
                            </div>

                            <button type="submit" class="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-sm cursor-pointer shadow-lg">
                                + Generate Customized Card Link
                            </button>
                        </form>
                    </div>

                    <div class="bg-[#1C2019] border border-white/10 rounded-2xl p-6">
                        <h3 class="text-sm font-semibold text-amber-400 mb-1">Public Link Default Programs</h3>
                        <p class="text-xs text-stone-400 mb-3">
                            Programs shown when opened without a personal guest token:
                        </p>
                        <form method="POST" class="space-y-3">
                            <input type="hidden" name="form_action" value="save_public_events">
                            <?php
                                $pubAllowed = $config['public_events'];
                                foreach (($config['events'] ?? []) as $ev):
                                    $isChecked = ($pubAllowed === null) || in_array($ev['id'], $pubAllowed, true);
                            ?>
                                <label class="flex items-center gap-2.5 text-xs text-stone-200 cursor-pointer">
                                    <input type="checkbox" name="public_events[]" value="<?= htmlspecialchars($ev['id']) ?>" <?= $isChecked ? 'checked' : '' ?> class="w-4 h-4 rounded accent-amber-500">
                                    <span><?= htmlspecialchars($ev['title']) ?></span>
                                </label>
                            <?php endforeach; ?>
                            <button type="submit" class="w-full py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold transition cursor-pointer">
                                Save Public Default
                            </button>
                        </form>
                    </div>
                </div>

                <div class="lg:col-span-2 bg-[#1C2019] border border-white/10 rounded-2xl p-6">
                    <div class="flex items-center justify-between mb-4">
                        <h2 class="text-lg font-semibold text-amber-400">Guest Cards Ready to Send (<?= count($guests) ?>)</h2>
                        <span class="text-xs text-stone-400">Customize Template &amp; Events Anytime</span>
                    </div>

                    <?php if (empty($guests)): ?>
                        <p class="text-sm text-stone-400 py-8 text-center">No guests added yet. Add names on the left to generate personalized links.</p>
                    <?php else: ?>
                        <div class="space-y-3.5 max-h-[820px] overflow-y-auto pr-1">
                            <?php foreach ($guests as $idx => $g): ?>
                                <?php
                                    $guestLink = $baseUrl . '?to=' . urlencode($g['token']);
                                    $gLang = $g['lang'] ?? 'default';
                                    $effectiveLang = ($gLang === 'default') ? ($config['template_lang'] ?? 'en') : $gLang;

                                    $dispBride = ($effectiveLang === 'bn' && !empty($config['bn_bride_name'])) ? $config['bn_bride_name'] : $config['bride_name'];
                                    $dispGroom = ($effectiveLang === 'bn' && !empty($config['bn_groom_name'])) ? $config['bn_groom_name'] : $config['groom_name'];

                                    if ($effectiveLang === 'bn') {
                                        $waText = rawurlencode("আসসালামু আলাইকুম {$g['name']}, {$dispBride} ও {$dispGroom}-এর শুভ বিবাহে আপনাকে সাদর আমন্ত্রণ। আপনার ব্যক্তিগত রাজকীয় নিমন্ত্রণপত্রটি খুলতে লিঙ্কে ক্লিক করুন: {$guestLink}");
                                    } else {
                                        $waText = rawurlencode("Assalamu Alaikum {$g['name']}, you are cordially invited to the wedding of {$dispBride} & {$dispGroom}. Tap to open your personal invitation card: {$guestLink}");
                                    }
                                    $gAllowed = $g['allowed_events'] ?? null;
                                ?>
                                <div class="p-4 rounded-xl bg-black/25 border border-white/10 space-y-3">
                                    <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                                        <div>
                                            <div class="flex flex-wrap items-center gap-2">
                                                <p class="font-semibold text-white text-sm"><?= htmlspecialchars($g['name']) ?></p>
                                                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-semibold <?= $effectiveLang === 'bn' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'bg-sky-500/20 text-sky-300 border border-sky-500/30' ?>">
                                                    <?= $effectiveLang === 'bn' ? 'Design 2: বাংলা রাজকীয়' : 'Design 1: English Royal' ?>
                                                </span>
                                                <?php if (($g['views'] ?? 0) > 0): ?>
                                                    <span class="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-semibold">
                                                        Opened <?= (int)$g['views'] ?>x
                                                    </span>
                                                <?php else: ?>
                                                    <span class="px-2 py-0.5 rounded-full bg-white/10 text-stone-400 text-[10px]">
                                                        Not opened yet
                                                    </span>
                                                <?php endif; ?>
                                            </div>

                                            <?php if (!empty($g['custom_note'])): ?>
                                                <p class="text-xs text-amber-200/90 mt-1">Note: “<?= htmlspecialchars($g['custom_note']) ?>”</p>
                                            <?php endif; ?>

                                            <div class="flex flex-wrap gap-1.5 mt-2">
                                                <?php if ($gAllowed === null): ?>
                                                    <span class="px-2 py-0.5 rounded bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[10px]">
                                                        All Programs
                                                    </span>
                                                <?php elseif (empty($gAllowed)): ?>
                                                    <span class="px-2 py-0.5 rounded bg-red-500/15 border border-red-500/30 text-red-300 text-[10px]">
                                                        No Programs Selected
                                                    </span>
                                                <?php else: ?>
                                                    <?php foreach ($gAllowed as $evId): ?>
                                                        <?php if (isset($eventTitleMap[$evId])): ?>
                                                            <span class="px-2 py-0.5 rounded bg-amber-500/15 border border-amber-500/30 text-amber-200 text-[10px]">
                                                                ✓ <?= htmlspecialchars($eventTitleMap[$evId]) ?>
                                                            </span>
                                                        <?php endif; ?>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                            </div>

                                            <p class="text-xs text-amber-300/75 font-mono mt-2 break-all"><?= htmlspecialchars($guestLink) ?></p>
                                            <?php if (!empty($g['last_viewed'])): ?>
                                                <p class="text-[11px] text-stone-400 mt-0.5">Last opened: <?= htmlspecialchars($g['last_viewed']) ?></p>
                                            <?php endif; ?>
                                        </div>

                                        <div class="flex flex-wrap items-center gap-1.5 shrink-0">
                                            <a href="<?= htmlspecialchars($guestLink) ?>" target="_blank" class="px-2.5 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold transition" title="Preview this exact card">
                                                Preview ↗
                                            </a>
                                            <button type="button" onclick="toggleGuestEditor('edit-box-<?= $idx ?>')" class="px-2.5 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 text-xs font-semibold transition cursor-pointer">
                                                Customize
                                            </button>
                                            <button type="button" onclick="copyInviteLink('<?= htmlspecialchars($guestLink, ENT_QUOTES) ?>', this)" class="px-2.5 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold transition cursor-pointer">
                                                Copy
                                            </button>
                                            <a href="https://wa.me/?text=<?= $waText ?>" target="_blank" rel="noopener noreferrer" class="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition">
                                                WhatsApp
                                            </a>
                                            <form method="POST" onsubmit="return confirm('Revoke and delete this guest link?');" class="inline">
                                                <input type="hidden" name="form_action" value="delete_guest">
                                                <input type="hidden" name="token" value="<?= htmlspecialchars($g['token']) ?>">
                                                <button type="submit" class="px-2 py-1.5 rounded-lg bg-red-500/15 hover:bg-red-500/30 text-red-300 text-xs transition cursor-pointer" title="Revoke Link">
                                                    ✕
                                                </button>
                                            </form>
                                        </div>
                                    </div>

                                    <!-- Collapsible Inline Customizer for Guest Card -->
                                    <form id="edit-box-<?= $idx ?>" method="POST" class="hidden pt-3 border-t border-white/10 space-y-3">
                                        <input type="hidden" name="form_action" value="update_guest_events">
                                        <input type="hidden" name="token" value="<?= htmlspecialchars($g['token']) ?>">

                                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                                            <div>
                                                <label class="block text-[10px] uppercase text-stone-400 mb-1">Guest Display Name</label>
                                                <input type="text" name="guest_name_edit" value="<?= htmlspecialchars($g['name']) ?>" class="w-full px-2.5 py-1.5 rounded-lg bg-black/40 border border-white/15 text-xs text-white">
                                            </div>
                                            <div>
                                                <label class="block text-[10px] uppercase text-stone-400 mb-1">Template Design</label>
                                                <select name="guest_lang" class="w-full px-2.5 py-1.5 rounded-lg bg-black/40 border border-amber-500/30 text-xs text-stone-200">
                                                    <option value="default" <?= $gLang === 'default' ? 'selected' : '' ?>>Default Global Setting</option>
                                                    <option value="bn" <?= $gLang === 'bn' ? 'selected' : '' ?>>Design 2: বাংলা রাজকীয়</option>
                                                    <option value="en" <?= $gLang === 'en' ? 'selected' : '' ?>>Design 1: English Royal</option>
                                                </select>
                                            </div>
                                            <div>
                                                <label class="block text-[10px] uppercase text-stone-400 mb-1">Custom Note (Optional)</label>
                                                <input type="text" name="guest_custom_note" value="<?= htmlspecialchars($g['custom_note'] ?? '') ?>" placeholder="Special note for guest" class="w-full px-2.5 py-1.5 rounded-lg bg-black/40 border border-white/15 text-xs text-white">
                                            </div>
                                        </div>

                                        <div class="flex flex-wrap items-center justify-between gap-3 pt-1">
                                            <div class="flex flex-wrap gap-3">
                                                <?php foreach (($config['events'] ?? []) as $ev): ?>
                                                    <?php $checked = ($gAllowed === null) || in_array($ev['id'], $gAllowed, true); ?>
                                                    <label class="flex items-center gap-1.5 text-xs text-stone-200 cursor-pointer">
                                                        <input type="checkbox" name="guest_events[]" value="<?= htmlspecialchars($ev['id']) ?>" <?= $checked ? 'checked' : '' ?> class="w-3.5 h-3.5 rounded accent-amber-500">
                                                        <span><?= htmlspecialchars($ev['title']) ?></span>
                                                    </label>
                                                <?php endforeach; ?>
                                            </div>
                                            <button type="submit" class="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold cursor-pointer">
                                                Save Changes
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        <?php elseif ($activeTab === 'rsvps'): ?>
            <div class="space-y-6">
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div class="p-5 rounded-2xl bg-[#1C2019] border border-white/10">
                        <p class="text-xs text-stone-400 uppercase tracking-wider">Confirmed Headcount</p>
                        <p class="text-3xl font-bold text-emerald-400 mt-1"><?= $attendingGuests ?></p>
                    </div>
                    <div class="p-5 rounded-2xl bg-[#1C2019] border border-white/10">
                        <p class="text-xs text-stone-400 uppercase tracking-wider">Unable to Attend</p>
                        <p class="text-3xl font-bold text-rose-400 mt-1"><?= $declinedCount ?></p>
                    </div>
                    <div class="p-5 rounded-2xl bg-[#1C2019] border border-white/10">
                        <p class="text-xs text-stone-400 uppercase tracking-wider">Total Responses</p>
                        <p class="text-3xl font-bold text-amber-400 mt-1"><?= count($rsvps) ?></p>
                    </div>
                </div>

                <div class="bg-[#1C2019] border border-white/10 rounded-2xl p-6">
                    <h2 class="text-lg font-semibold text-amber-400 mb-4">Guest RSVPs &amp; Wishes</h2>
                    <?php if (empty($rsvps)): ?>
                        <p class="text-sm text-stone-400 py-8 text-center">No RSVP responses submitted yet.</p>
                    <?php else: ?>
                        <div class="space-y-3">
                            <?php foreach (array_reverse($rsvps) as $r): ?>
                                <div class="p-4 rounded-xl bg-black/25 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                    <div>
                                        <div class="flex flex-wrap items-center gap-2">
                                            <span class="font-semibold text-white"><?= htmlspecialchars($r['name']) ?></span>
                                            <span class="px-2.5 py-0.5 rounded-full text-[11px] font-semibold <?= ($r['status'] ?? '') === 'Joyfully Attending' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300' ?>">
                                                <?= htmlspecialchars($r['status']) ?> (<?= (int)$r['guests'] ?>)
                                            </span>
                                            <span class="text-xs text-stone-500"><?= htmlspecialchars($r['created_at'] ?? '') ?></span>
                                        </div>
                                        <?php if (!empty($r['message'])): ?>
                                            <p class="text-sm text-stone-300 mt-2 italic">"<?= htmlspecialchars($r['message']) ?>"</p>
                                        <?php endif; ?>
                                    </div>
                                    <form method="POST" onsubmit="return confirm('Delete this RSVP entry?');">
                                        <input type="hidden" name="form_action" value="delete_rsvp">
                                        <input type="hidden" name="rsvp_id" value="<?= htmlspecialchars($r['id']) ?>">
                                        <button type="submit" class="px-3 py-1.5 rounded-lg bg-red-500/15 hover:bg-red-500/30 text-red-300 text-xs cursor-pointer">Delete</button>
                                    </form>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

    </main>

    <script>
        function fillBanglaSampleTexts() {
            document.getElementById('bn_monogram').value = 'শুভ বিবাহ';
            document.getElementById('bn_bismillah_text').value = 'পরম করুণাময় ও অসীম দয়ালু আল্লাহর নামে শুরু করছি';
            document.getElementById('bn_tagline').value = 'দুটি প্রাণের পবিত্র মিলন — ভালোবাসা ও দোয়ায় নতুন পথচলা';
            document.getElementById('bn_parents_text').value = 'জনাব মজিবুল হক ও মিসেস মজিবুল হক-এর স্নেহধন্য কন্যার শুভ বিবাহ উপলক্ষে';
            document.getElementById('bn_invite_message').value = 'আমাদের প্রিয় কন্যার শুভ বিবাহের এই আনন্দঘন মুহূর্তে আপনার ও আপনার পরিবারের সাদর উপস্থিতি এবং আন্তরিক দোয়া আমাদের একান্ত কাম্য।';
        }

        function toggleAllCreateEvents(state) {
            document.querySelectorAll('.create-event-cb').forEach(cb => cb.checked = state);
        }

        function toggleGuestEditor(id) {
            const el = document.getElementById(id);
            if (el) el.classList.toggle('hidden');
        }

        function copyInviteLink(url, btn) {
            navigator.clipboard.writeText(url).then(function() {
                const orig = btn.textContent;
                btn.textContent = 'Copied!';
                btn.classList.add('bg-emerald-600', 'text-white');
                setTimeout(function() {
                    btn.textContent = orig;
                    btn.classList.remove('bg-emerald-600', 'text-white');
                }, 1600);
            });
        }

        function addEventRow() {
            const randId = 'ev_' + Math.random().toString(36).substring(2, 10);
            const html = `
                <div class="p-4 rounded-xl bg-black/25 border border-white/10 space-y-3 relative event-row">
                    <input type="hidden" name="event_id[]" value="${randId}">
                    <button type="button" onclick="this.parentElement.remove()" class="absolute top-3 right-3 text-xs text-red-400 hover:underline">Remove</button>
                    <p class="text-[11px] uppercase tracking-wider text-stone-400 font-semibold">English Details (Design 1)</p>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <input type="text" name="event_title[]" placeholder="Event Title (EN)" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                        <input type="text" name="event_date[]" placeholder="Date (EN)" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                        <input type="text" name="event_time[]" placeholder="Time (EN)" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <input type="text" name="event_venue[]" placeholder="Venue Address (EN)" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                        <input type="text" name="event_dress[]" placeholder="Dress Code (EN)" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                        <input type="url" name="event_map[]" placeholder="Google Maps URL" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                    </div>
                    <p class="text-[11px] text-amber-300/80 font-['Noto_Serif_Bengali'] pt-1">বাংলা অনুবাদ (Design 2 — ঐচ্ছিক)</p>
                    <div class="grid grid-cols-1 md:grid-cols-5 gap-2.5">
                        <input type="text" name="event_bn_title[]" placeholder="অনুষ্ঠানের নাম (বাংলা)" class="px-3 py-2 rounded-lg bg-black/30 border border-amber-500/20 text-xs font-['Noto_Serif_Bengali']">
                        <input type="text" name="event_bn_date[]" placeholder="তারিখ (বাংলা)" class="px-3 py-2 rounded-lg bg-black/30 border border-amber-500/20 text-xs font-['Noto_Serif_Bengali']">
                        <input type="text" name="event_bn_time[]" placeholder="সময় (বাংলা)" class="px-3 py-2 rounded-lg bg-black/30 border border-amber-500/20 text-xs font-['Noto_Serif_Bengali']">
                        <input type="text" name="event_bn_venue[]" placeholder="স্থান / ভেন্যু (বাংলা)" class="px-3 py-2 rounded-lg bg-black/30 border border-amber-500/20 text-xs font-['Noto_Serif_Bengali']">
                        <input type="text" name="event_bn_dress[]" placeholder="পোশাক (বাংলা)" class="px-3 py-2 rounded-lg bg-black/30 border border-amber-500/20 text-xs font-['Noto_Serif_Bengali']">
                    </div>
                </div>`;
            document.getElementById('events-container').insertAdjacentHTML('beforeend', html);
        }

        function addContactRow() {
            const html = `
                <div class="grid grid-cols-1 sm:grid-cols-4 gap-3 items-center">
                    <input type="text" name="contact_name[]" placeholder="Name / Relation (EN)" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                    <input type="text" name="contact_bn_name[]" placeholder="নাম / পরিচয় (বাংলা - ঐচ্ছিক)" class="px-3 py-2 rounded-lg bg-black/30 border border-amber-500/20 text-sm font-['Noto_Serif_Bengali']">
                    <input type="text" name="contact_phone[]" placeholder="+8801XXXXXXXXX" class="px-3 py-2 rounded-lg bg-black/30 border border-white/15 text-sm">
                    <button type="button" onclick="this.parentElement.remove()" class="text-xs text-red-400 hover:underline text-left sm:text-center">Remove</button>
                </div>`;
            document.getElementById('contacts-container').insertAdjacentHTML('beforeend', html);
        }
    </script>
</body>
</html>
